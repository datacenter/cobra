#!/usr/bin/env python
import sys
sys.path.insert(0,'..')
import cobra.mit.request
import cobra.mit.session
import cobra.mit.access
from cobra.internal.codec.xmlcodec import toXMLStr
moDir = cobra.mit.access.MoDirectory(cobra.mit.session.LoginSession('http://172.23.3.215', 'admin', open('password.txt','r').read().strip()))

moDir.login()

nodes = moDir.lookupByClass('fabricNode', propFilter='eq(fabricNode.role,"leaf"')
for node in nodes:
	for t in ['fvEpP', 'vlanCktEp', 'actrlRule']:
		a = cobra.mit.request.TraceQuery(node.dn, t)
		# a.subtree='full'
		print a.getUrl(moDir._accessImpl._session)
		mos = moDir.query(a)
		for mo in mos:
			print ' ' * 4, mo.dn
