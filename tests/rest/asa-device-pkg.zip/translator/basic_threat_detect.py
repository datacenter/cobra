'''
Created on Aug 27, 2013

@author: tsnguyen
'''

from translator.state_type import State, Type
from translator.base.dmobject import DMObject
from translator.base.simpletype import SimpleType
import utils.util as util

import asaio.cli_interaction as cli_interaction


class BasicThreatDetection(DMObject):
    '''
    Basic Threat Detection
    Supports the following CLI:

    threat-detection basic-threat

    threat-detection rate {acl-drop | bad-packet-drop | conn-limit-drop |
        dos-drop | fw-drop | icmp-drop | inspect-drop | interface-drop |
        scanning-threat | syn-attack} rate-interval rate_interval average-rate
        av_rate burst-rate burst_rate
    '''

    THREAT_DETECTION = "threat-detection"
    RATE_OPTIONS = ['acl-drop', 'bad-packet-drop', 'conn-limit-drop', 'dos-drop', 'fw-drop', 'icmp-drop', 'inspect-drop', 'interface-drop', 'scanning-threat', 'syn-attack']
    def __init__(self):
        '''
        Constructor
        '''
        DMObject.__init__(self, BasicThreatDetection.__name__)
        
        self.register_child(SimpleBasicThreat("basic_threat", 'threat-detection basic-threat', on_value="enable",
             response_parser=cli_interaction.ignore_warning_response_parser)) 
        
        for rate_type in self.RATE_OPTIONS:
            self.register_child(BasicThreatRate("BasicThreatDetectionRateOptions", 'threat-detection rate ' + rate_type)) 
        
    def __repr__(self):
        return "Basic Threat Detection"
    
class BasicThreatRate(SimpleType):    
    ''' Class to handle CLI:
    threat-detection rate {acl-drop | bad-packet-drop | conn-limit-drop |
        dos-drop | fw-drop | icmp-drop | inspect-drop | interface-drop |
        scanning-threat | syn-attack} rate-interval rate_interval average-rate
        av_rate burst-rate burst_rate '''

    def __init__(self, name, asa_key):
        '''Constructor '''
        
        SimpleType.__init__(self, name, asa_key,
            asa_gen_template = 'threat-detection rate %(rate)s rate-interval %(rate_interval)s average-rate %(average_rate)s burst-rate %(burst_rate)s',
            response_parser = cli_interaction.ignore_warning_response_parser)
    

    def get_cli(self):
        '''Generate the CLI for this single config.
        '''
        assert self.has_ifc_delta_cfg()
        
        state = self.delta_ifc_cfg_value['state']
        config = util.normalize_param_dict(self.delta_ifc_cfg_value['value'])
        if not config:
            return ''
       
        if not isinstance(config, dict):
            return ''
        status = config.get('rate_status')
        no_cmd = ''
        if state != State.DESTROY and status and status.startswith('disable'):
            no_cmd = 'no '
        
        cli = no_cmd + (self.asa_gen_template % config)
       
        return cli
    
    def parse_multi_parameter_cli(self, cli, asa_gen_template):
        result = SimpleType.parse_multi_parameter_cli(self, cli, alternate_asa_gen_template = self.asa_gen_template)
        status = 'enable'
        if cli.startswith('no '):
            status = 'disable'
        if isinstance(result, dict):
            result[(Type.PARAM, 'rate_status', 'rate_status')] = {'state': State.NOCHANGE, 'value': status}
        return result
   
    
class SimpleBasicThreat(SimpleType):
    ''' Translator for the type of CLI that turns on/off basic threat
    threat-detection basic-threat
    '''
    def __init__(self, ifc_key, asa_key, on_value, response_parser):
        '''
        @param on_value: str
            The value in the dictionary to turn on the feature, e.g. 'enable'
        '''
        SimpleType.__init__(self, ifc_key, asa_key)
        self.on_value = on_value
        self.response_parser = response_parser

    def get_cli(self):
        '''Override get_cli'''
        assert self.has_ifc_delta_cfg()
        
        config = util.normalize_param_dict(self.delta_ifc_cfg_value['value'])
        
        if not config:
            return ''
        if str(config).startswith('disable'):
            return 'no ' + self.asa_key
        
        return self.asa_key

    def parse_cli(self, cli):
        '''Override parse_cli'''
        if cli.endswith('basic-threat'):
            return 'disable' if cli.startswith('no ') else self.on_value
        return cli

