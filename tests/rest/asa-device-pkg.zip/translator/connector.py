'''
Copyright (c) 2013 by Cisco Systems, Inc.

@author: emilymw
'''

import translator
from base.dmobject import DMObject
from translator.state_type import State, Type
from translator.base.dmlist import DMList
import asaio.cli_interaction as cli_interaction
import utils.util as util
from translator.structured_cli import StructuredCommand

class Connectors(DMList):
    def __init__(self, name, child_class, asa_key=''):
        DMList.__init__(self, name, child_class, asa_key)
        self.asa_key = 'interface'

    def is_my_cli(self, cli):
        'Overwrite is_my_cli check, cli is a StructuredCommand in our case'
        if isinstance(cli, str):
            return False # not handled by us
        
        'Must be an interface'
        if not cli.command.startswith('interface '):
            return False
        
        'Must be a vlan interface'
        vlan = filter(lambda cmd: cmd.startswith('vlan'), cli.sub_commands)
        if len(vlan) == 0:
            return False

        'Must bave instance name starting with external or internal'
        nameif = filter(lambda cmd: cmd.startswith('nameif'), cli.sub_commands)
        if len(nameif) == 0:
            return False
        
        return 'external_' in nameif[0] or 'internal' in nameif[0]

class Connector(DMObject):
    '''
    A firewall service can contains two connectors of type external and internal.  A
    Connector in terms of ASA CLI is expressed by a VLAN interface.

    There are several ConnObj (VIF, VLAN, ENCAPASS) objects defined in the global
    configuration under Device Config.  These objects binds the vlan tag with the interface.

    When Connector generation CLI in ifc2asa() it retrieves the ConnObj that are
    associated with this Connector and invoke the ConnObj gen_ifc2asa().  gen_ifc2asa()
    is a function similar to DMObject.ifc2asa(), however, gen_ifc2asa() will be called
    by the Connector only.
    '''
    is_same_security_traffic = False  # static variable to track same-security-traffic is generated
    
    def is_my_cli(self, cli):
        'Overwrite is_my_cli check, cli is a StructuredCommand in our case'
        if isinstance(cli, str):
            return False # not handled by us

        'Must be a vlan interface'
        vlan = filter(lambda cmd: cmd.startswith('vlan'), cli.sub_commands)
        if len(vlan) == 0:
            return False

        'Must have instance name presenting external or internal connector'
        nameif = filter(lambda cmd: cmd.startswith('nameif'), cli.sub_commands)
        instance = nameif[0].split(' ',1)[1]
        
        self.get_connector_object()
        vif_obj = self.conn_obj.get('VIF')
        vlan_obj = self.conn_obj.get('VLAN')
        cli_dict = {}
        for c in cli.sub_commands:
            key = c.split(' ', 1)[0]
            cli_dict[key] = c

        intf_command = 'interface %s.' % (vif_obj.value) 
        vlan = cli_dict['vlan'].split(' ', 1)[1]
        
        'Check if interface command, nameif and vlan id are the same with the cli'
        return self.instance_name == instance and cli.command.startswith(intf_command) and vlan == str(vlan_obj.tag)

    def populate_model(self, delta_ifc_key, delta_ifc_cfg_value):
        '''
        Populate the Connector configuration
        '''
        self.delta_ifc_key = delta_ifc_key
        self.delta_ifc_cfg_value = delta_ifc_cfg_value
        self.state = delta_ifc_cfg_value['state']
        self.config = util.normalize_param_dict(delta_ifc_cfg_value['value'])
        type, blank, self.instance_name  = self.delta_ifc_key
        if self.instance_name.startswith('external_'):
            self.conn_type = 'external'
        else:
            self.conn_type = 'internal'

    def get_nameif(self):
        return self.instance_name

    def get_intf_config_rel(self):
        if self.conn_type == 'external':
            return self.get_ancestor_by_class(translator.devicemodel.Firewall).get_child('ExIntfConfigRelFolder').get_child('ExIntfConfigRel')
        else:
            return self.get_ancestor_by_class(translator.devicemodel.Firewall).get_child('InIntfConfigRelFolder').get_child('InIntfConfigRel')

    def get_connector_object(self):
        '''
        Traverse to DeviceConfig and get the children ENCAPASS, VLAN, VIF, ip address and mask
        for this connector
        '''
        shared_config = self.get_top()
        ass_list = shared_config.get_child('ENCAPASS')
        vlan_list = shared_config.get_child('VLAN')
        vif_list = shared_config.get_child('VIF')
        address_list = shared_config.get_child('InterfaceConfig')
        intf_config_rel = self.get_intf_config_rel()

        self.conn_obj = {}
        self.conn_obj['ENCAPASS'] = ass_list.get_child(self.config.get('ENCAPREL'))
        if (self.conn_obj['ENCAPASS']):
            self.conn_obj['VLAN'] = vlan_list.get_child(self.conn_obj['ENCAPASS'].encap)
            self.conn_obj['VIF'] = vif_list.get_child(self.conn_obj['ENCAPASS'].vif)
        
        if hasattr(intf_config_rel, 'value'):
            self.conn_obj['IPAddress'] = address_list.get_child(intf_config_rel.value)

    def ifc2asa(self, no_asa_cfg_stack, asa_cfg_list):
        '''
        1. Enable the physical or port-channel interface
        Example:
            interface port-channel1
              no shutdown
              nameif outside-1

        2. Create subinterface from physical or port-channel interface
            interface port-channel1.10
              vlan 10
              nameif external_Conn1
              security-level 100
              ip address 10.10.10.10 255.255.255.128

        There are three things that asa-dp has massaged on top of IFC configuration
        1. Mapped vlan tag as the port number of subinterface.
        2. Mapped Connector type and instance name as nameif.
           This may likely be changed but it is now a place holder.
        3. Set security-level to 100 by default, and set same-security-traffic once
        4. Added relationship to interface config for ip address/mask
        Note:  ASA will require interface to have nameif, security-level, ip address
        to work properly.
        '''
        if not self.has_ifc_delta_cfg():
            return

        if not Connector.is_same_security_traffic:
            'Generate same-security-traffic only once'
            self.generate_cli(asa_cfg_list, 'same-security-traffic permit inter-interface')
            Connector.is_same_security_traffic = True

        self.get_connector_object()

        if self.state == State.NOCHANGE:
            return

        vif_obj = self.conn_obj.get('VIF')
        vlan_obj = self.conn_obj.get('VLAN')
        ip_obj = self.conn_obj.get('IPAddress')

        'First, generate CLI for physical or virtual interface'
        vif_obj.gen_ifc2asa(no_asa_cfg_stack, asa_cfg_list)

        'Second, generate CLI for VLAN interface'
        'user error if vlan is in MODIFY state'
        interface_command = 'interface %s.%s' % (vif_obj.value, vlan_obj.tag)
        if self.state == State.DESTROY:
            self.generate_cli(no_asa_cfg_stack, 'no ' + interface_command)
        elif self.state in [State.CREATE, State.MODIFY]:
            self.mode_command = interface_command
            self.response_parser = cli_interaction.ignore_info_response_parser
            vlan_obj.gen_ifc2asa(no_asa_cfg_stack, asa_cfg_list, interface_command)
            'For now use Connector type and instance name for nameif'
            self.generate_cli(asa_cfg_list, 'nameif ' + self.get_nameif())
            if self.state in [State.CREATE]:
                'By default, always set security-level to 100'
                self.generate_cli(asa_cfg_list, 'security-level ' + '100')
            ip_obj.gen_ifc2asa(no_asa_cfg_stack, asa_cfg_list, interface_command)

    def diff_ifc_asa(self, cli):
        '''
        Check if any state needs to be updated.  If it has no ifc delta config,
        we should remove this CLI from ASA.
        '''
        self.is_removable = True
        if not self.has_ifc_delta_cfg():
            if self.is_removable: #delete operation required
                self.gen_destroy_conn_obj_delta_ifc_value(cli.command)
                self.gen_destroy_conn_delta_ifc_value(cli.command)
            return
        if isinstance(cli, str):
            assert cli.strip().startswith(self.get_asa_key())
        elif isinstance(cli, StructuredCommand):
            assert cli.command.startswith(self.get_asa_key())
        self.updateState(cli)
    
    def gen_destroy_conn_delta_ifc_value(self, cli):
        intf, vlan = cli.split(' ')[1].split('.')
        ass = 'DEL_' + intf
        key = (Type.CONN, 'CONN','')
        config = {'state': State.DESTROY, 'value': {
            (Type.ENCAPREL, '', ''): {'state':State.DESTROY, 'value':ass}
        }}
        "add it to its container's delta_ifc_cfg_value"
        ancestor = self.get_ifc_delta_cfg_ancestor()
        ancestor.delta_ifc_cfg_value['value'][key] = config

    def gen_destroy_conn_obj_delta_ifc_value(self, cli):
        'Split CLI into interface and vlan'
        intf, vlan = cli.split(' ')[1].split('.')
        
        'Create DEL_ instance names for new conn_obj config'
        assoc = 'DEL_' + intf
        encap = 'DEL_VLAN-' + vlan
        vif = 'DEL_' + intf + '_' + vlan
        
        'Create key an values'
        encapass_key = (Type.ENCAPASS, '', assoc)
        encapass_config = {'state': State.DESTROY, 'encap':encap, 'vif':vif}
        
        encap_key = (Type.ENCAP, '', encap)
        encap_config = {'state': State.DESTROY, 'tag':vlan, 'type':'0'}
        
        vif_key = (Type.VIF, '', vif)
        vif_config = {'state': State.DESTROY, 'cifs':{'FW1':intf}}  # TODO 'FW1' should be generate
        
        "Add the key-value config to its container's delta_ifc_cfg_value"
        ancestor = self.get_top()
        ancestor.delta_ifc_cfg_value['value'][vif_key] = vif_config
        ancestor.delta_ifc_cfg_value['value'][encap_key] = encap_config
        ancestor.delta_ifc_cfg_value['value'][encapass_key] = encapass_config
            
    def updateState(self, cli):
        '''
        Update the state if necessary
        '''
        self.get_connector_object()
        vif_obj = self.conn_obj.get('VIF')
        vlan_obj = self.conn_obj.get('VLAN')
        ip_obj = self.conn_obj.get('IPAddress')
        
        cli_dict = {}
        for c in cli.sub_commands:
            key = c.split(' ', 1)[0]
            cli_dict[key] = c
            
        accum_state = []
        '1 - vif: interface <label.port>'
        accum_state.append(vif_obj.gen_diff_ifc_asa(cli.command))
        if State.CREATE in accum_state:
            self.gen_destroy_conn_delta_ifc_value(cli.command)
            self.gen_destroy_shared_delta_ifc_ENCAPASS_value(cli.command)
            return
        '2 - vlan <num>'
        accum_state.append(vlan_obj.gen_diff_ifc_asa(cli_dict['vlan']))
        if State.CREATE in accum_state:
            self.gen_destroy_conn_delta_ifc_value(cli.command)            
            self.gen_destroy_shared_delta_ifc_ENCAPASS_value(cli.command)
            return
        '3 - ip address <ip> <mask>'
        accum_state.append(ip_obj.gen_diff_ifc_asa(cli_dict['ip']))
        if State.MODIFY in accum_state:
            self.state = State.MODIFY

class ConnObj(DMObject):
    '''
    This is a base class for all connector objects that are defined under
    Device Config (VIF, VLAN, ENCAPASS, InterfaceConfig).  It overwrite the populate_model()
    and ifc2asa() method. The Connector will handle the generation of CLI
    instead of handling it in these objects.

    Note:  ConnObj are not specified in device specification, they are
    generated by the IFC, except InterfaceConfig which is a relationship binding
    interface to ip address/mask.
    '''
    def populate_model(self, delta_ifc_key, delta_ifc_cfg_value):
        self.delta_ifc_key = delta_ifc_key
        self.delta_ifc_cfg_value = delta_ifc_cfg_value
        self.state = delta_ifc_cfg_value['state']

    def ifc2asa(self, no_asa_cfg_stack, asa_cfg_list):
        'Handled by Connector'
        pass

class Vif(ConnObj):
    '''
    Virtual interface or physical interface that vlan interface will spawn from
    '''
    def populate_model(self, delta_ifc_key, delta_ifc_cfg_value):
        '''
        Populate model
        '''
        super(Vif, self).populate_model(delta_ifc_key, delta_ifc_cfg_value)
        self.value = delta_ifc_cfg_value['cifs'].iteritems().next()[1]
        self.value = self.value.replace('_', '/')

    def gen_ifc2asa(self, no_asa_cfg_stack, asa_cfg_list):
        '''
        Generate ASA configuration from IFC configuration delta.
        May need to created and/or enable this interface.  This is not the vlan interface,
        it is the interface where it is sub interface from.
        '''
        if not self.has_ifc_delta_cfg():
            return

        if self.state == State.NOCHANGE:
            return

        cli = 'interface ' + self.value
        if self.state == State.DESTROY:
            'Cannot delete physical interface GigabitEthernet, Ethernet, Management'
            if self.value[0] not in ['G', 'g','E','e','M', 'm']:
                self.generate_cli(no_asa_cfg_stack, 'no ' + cli)
        if self.state in [State.CREATE, State.MODIFY]:
            self.mode_command = cli
            self.generate_cli(asa_cfg_list, 'no shutdown')
            if self.state == State.CREATE:
                self.generate_cli(asa_cfg_list, 'nameif ' + self.ifc_key)
                   
    def gen_diff_ifc_asa(self, interface):
        '''
        Check if any state changes needed.
        '''
        intf_command = 'interface %s.' % (self.value) 
        if not interface.startswith(intf_command):
            self.delta_ifc_cfg_value['state'] = State.CREATE
        else:
            self.delta_ifc_cfg_value['state'] = State.NOCHANGE
        return self.delta_ifc_cfg_value['state']     
        
class Vlan(ConnObj):
    '''
    Describe the VLAN tag
    '''
    def populate_model(self, delta_ifc_key, delta_ifc_cfg_value):
        '''
        Populate model
        '''
        super(Vlan, self).populate_model(delta_ifc_key, delta_ifc_cfg_value)
        self.type = delta_ifc_cfg_value['type']
        self.tag = delta_ifc_cfg_value['tag']

    def gen_ifc2asa(self, no_asa_cfg_stack, asa_cfg_list, mode):
        '''
        Create VLAN tag
        '''
        if not self.has_ifc_delta_cfg():
            return

        '''
        MODIFY state is not supported, modify a VLAN will modify the subinterface port
        number which will create a different interface instead of modifying the current
        specified port-channel.
        '''
        if self.state == State.NOCHANGE:
            return

        if self.state in [State.CREATE, State.MODIFY]:
            self.mode_command = mode
            self.generate_cli(asa_cfg_list, 'vlan %s' %(self.tag))

    def gen_diff_ifc_asa(self, vlan):
        '''
        Check if any state changes needed
        '''
        vlan = vlan.split(' ', 1)[1]
        
        if vlan != str(self.tag):
            self.delta_ifc_cfg_value['state'] = State.MODIFY
        else:
            self.delta_ifc_cfg_value['state'] =  State.NOCHANGE
        return self.delta_ifc_cfg_value['state']  
        
class EncapAss(ConnObj):
    '''
    Present the association of VLAN and VIF
    '''
    def populate_model(self, delta_ifc_key, delta_ifc_cfg_value):
        '''
        Populate model
        '''
        super(EncapAss, self).populate_model(delta_ifc_key, delta_ifc_cfg_value)
        self.vif = delta_ifc_cfg_value['vif']
        self.encap = delta_ifc_cfg_value['encap']

class IntfConfigRel(DMObject):
    '''
    Populate interfaceConfig for external or internal connector
    '''
    def populate_model(self, delta_ifc_key, delta_ifc_cfg_value):
        '''
        Populate model
        '''
        self.delta_ifc_key = delta_ifc_key
        self.delta_ifc_cfg_value = delta_ifc_cfg_value
        self.state = delta_ifc_cfg_value['state']
        'Will deprecate check for target once the target is replaced with value in the initialization'
        if 'target' in delta_ifc_cfg_value:
            self.value = delta_ifc_cfg_value['target']
        else:
            self.value = delta_ifc_cfg_value['value']

class ExIntfConfigRel(IntfConfigRel):
    def __init__(self):
        DMObject.__init__(self, ExIntfConfigRel.__name__)

class InIntfConfigRel(IntfConfigRel):
    def __init__(self):
        DMObject.__init__(self, InIntfConfigRel.__name__)

class IPAddress(ConnObj):
    '''
    Relate ip address on the vlan interface
    Currently only support IPv4 for the demo, IPv6 will be added afterwards
    '''
    def populate_model(self, delta_ifc_key, delta_ifc_cfg_value):
        '''
        Populate model
        '''
        self.delta_ifc_key = delta_ifc_key
        self.delta_ifc_cfg_value = delta_ifc_cfg_value
        self.state = delta_ifc_cfg_value['state']
        'Has two parameter Address and Mask stored in self.config'
        self.config = util.normalize_param_dict(delta_ifc_cfg_value['value'])

    def gen_ifc2asa(self, no_asa_cfg_stack, asa_cfg_list, mode):
        '''
        Modify an ip address required a "no" CLI first then the new ip address
        "no" CLI will be using asa_cfg_list because it is in a submode
        '''
        if not self.has_ifc_delta_cfg():
            return

        if self.state == State.NOCHANGE:
            return

        self.mode_command = mode
        if self.state in [State.DESTROY, State.MODIFY]:
            self.generate_cli(asa_cfg_list, 'no ip address')
        if self.state in [State.CREATE, State.MODIFY]:
            'Mask is optional, user may not provide a value'
            cli = 'ip address ' + self.config['Address']
            if 'Mask' in self.config:
                cli += ' ' + self.config['Mask']

            self.generate_cli(asa_cfg_list, cli)

    def gen_diff_ifc_asa(self, ip):
        '''
        Check if any state changes needed
        '''
        address, mask = (ip.split(' ', 2)[2]).split(' ')
        tmp_state = State.NOCHANGE
        
        if address != self.config['Address']:
            self.config['Address_state'] = State.MODIFY
            tmp_state = State.MODIFY
        else:
            self.config['Address_state'] = State.NOCHANGE
            
        if mask != self.config['Mask']:
            self.config['Mask_state'] = State.MODIFY
            tmp_state = State.MODIFY
        else:
            self.config['Mask_state'] = State.NOCHANGE
        
        self.delta_ifc_cfg_value['state'] = tmp_state
        return self.delta_ifc_cfg_value['state']
            
class ExIntfConfigRelFolder(DMObject):
    'A list of additional interface parameters for external Connectors'

    def __init__(self):
        DMObject.__init__(self, ExIntfConfigRelFolder.__name__)
        self.register_child(ExIntfConfigRel())

class InIntfConfigRelFolder(DMObject):
    'A list of additional interface parameters for internal Connectors'

    def __init__(self):
        DMObject.__init__(self, InIntfConfigRelFolder.__name__)
        self.register_child(InIntfConfigRel())
