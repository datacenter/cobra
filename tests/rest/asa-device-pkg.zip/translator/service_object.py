'''
Copyright (c) 2013 by Cisco Systems, Inc.

@author: emilymw
'''
import re
from base.simpletype import SimpleType
from base.dmlist import DMList
from base.compositetype import SubCommand
from network_object import Description, _ObjectNetwork, _ObjectNetworks
from state_type import State
from utils.util import normalize_param_dict, ifcize_param_dict

class _ObjectServices(_ObjectNetworks):
    'Base class for the containers'
    def __init__(self, name, child_class, asa_sub_key):
        DMList.__init__(self, name, child_class, asa_key = 'object service')
        self.asa_sub_key = asa_sub_key

class ICMP4Objects(_ObjectServices):
    'Container for ICMP4Object'
    def __init__(self):
        _ObjectServices.__init__(self, 'ICMPObject', ICMP4Object, asa_sub_key = 'service icmp ')
        #@note: keep the space after 'icmp' in asa_sub_key to differentiate it from icmp6

class ICMP6Objects(_ObjectServices):
    'Container for ICMP6Object'
    def __init__(self):
        _ObjectServices.__init__(self, 'ICMP6Object', ICMP6Object, asa_sub_key = 'service icmp6')


class ProtocolObjects(_ObjectServices):
    'Container for ProtocolObject'
    def __init__(self):
        'Anything other service other than icmp, icmp6, tcp, udp'
        _ObjectServices.__init__(self, 'ProtocolObject', ProtocolObject, asa_sub_key = 'service (?!icmp|icmp6|tcp|udp)')

class TCPObjects(_ObjectServices):
    'Container for TCPObject'
    def __init__(self):
        _ObjectServices.__init__(self, 'TCPObject', TCPObject, asa_sub_key = 'service tcp')

class UDPObjects(_ObjectServices):
    'Container for TCPObject'
    def __init__(self):
        _ObjectServices.__init__(self, 'UDPObject', UDPObject, asa_sub_key = 'service udp')

class _ObjectService(_ObjectNetwork):
    '''Base class 'object network' CLI object. This is the base type for all rest classes in this module
    '''
    def __init__(self, name):
        SimpleType.__init__(self, name,
                            asa_gen_template='object service %(name)s');
        self.register_child(Description())

class ICMP4Object(_ObjectService):
    '''Model after 'object service\n service icmp ' object
    '''
    def __init__(self, name):
        _ObjectService.__init__(self, name)
        self.register_child(ICMPCommand())

class ICMP6Object(_ObjectService):
    '''Model after 'object service\n service icmp6' object
    '''
    def __init__(self, name):
        _ObjectService.__init__(self, name)
        self.register_child(ICMPCommand(True))

class ProtocolObject(_ObjectService):
    '''Model after 'object service\n service \d+' object
    '''
    def __init__(self, name):
        _ObjectService.__init__(self, name)
        self.register_child(SubCommand(ifc_key = '',
                                       asa_key= 'service',
                                       asa_gen_template = 'service %(protocol_type)s'))

class TCPObject(_ObjectService):
    '''Model after 'object service\n service tcp object
    '''
    def __init__(self, name):
        _ObjectService.__init__(self, name)
        self.register_child(TCPUDPCommand('tcp'))

class UDPObject(_ObjectService):
    '''Model after 'object service\n service icmp6' object
    '''
    def __init__(self, name):
        _ObjectService.__init__(self, name)
        self.register_child(TCPUDPCommand('udp'))

class TCPUDPCommand(SubCommand):
    def __init__(self, kind):
        SubCommand.__init__(self,
                            ifc_key = '',
                            asa_key = 'service ' + kind,
                            asa_gen_template = 'service ' + kind + ' %(source)s %(destination)s')

    def get_cli(self):
        'Override the default implementation to take care of the variations of the command'
        assert self.has_ifc_delta_cfg()
        value = normalize_param_dict(self.delta_ifc_cfg_value['value'])
        for name in ['source', 'destination']:
            if value.get(name) and self.get_state_for_entry(name) != State.DESTROY:
                folder = value[name]
                op = folder.get('operator')
                value[name] = ' '.join([name, op, folder.get('low_port'),
                                        folder.get('high_port')  if 'range' == op.lower() else ''])
            else:
                value[name] = ''

        return ' '.join((self.asa_gen_template % value).split())

    def parse_cli(self, cli):
        'Override the default to handle variations of the command'
        result = {}
        parameters = cli[len(self.asa_key):].strip()
        if not parameters:
            return ifcize_param_dict(result)

        def parse_parameters(items):
            folder = items[0]
            result[folder] = {}
            result[folder]['operator'] = items[1]
            result[folder]['low_port'] = items[2]
            if len(items) == 4:
                result[folder]['high_port'] = items[3]

        pattern = '(source .+) (destination .+)'
        match = re.compile(pattern).match(cli)
        if match:
            parse_parameters(match.group(1).split())
            parse_parameters(match.group(2).split())
        else: #of the form 'source|destination <operator> ..'
            parse_parameters(parameters.split())
        return ifcize_param_dict(result)

    def get_action(self):
        '''Override the default implementation to take care of State.DESTROY, which means both "source" and "destination" are absent.
        For us, this does not mean to wipe out the command, but rather the simple form of the CLI, 'service tcp' or "service udp"
        '''
        result = SubCommand.get_action(self)
        return State.MODIFY if result == State.DESTROY else result

class ICMPCommand(SubCommand):
    'Model of "service icmp %(type)s %(code)s" sub-command'
    def __init__(self, is_v6 = False):
        self.is_v6 = is_v6
        SubCommand.__init__(self,
                           ifc_key = '',
                           asa_key = 'service icmp6' if is_v6 else 'service icmp ',
                           asa_gen_template = 'service icmp6 %(type)s %(code)s' if is_v6 else 'service icmp %(type)s %(code)s')
    def get_cli(self):
        'Override the default to take care of the optional "code" parameter'
        if self.get_state_for_entry('code') in (State.DESTROY, None):
            return (self.asa_key.strip() + ' %(type)s') % normalize_param_dict(self.delta_ifc_cfg_value['value'])
        else:
            return SubCommand.get_cli(self)

    def parse_multi_parameter_cli(self, cli):
        '''Override the default implementation in case the CLI does not match asa_gen_template due to optional
        parameter
        '''
        result = SimpleType.parse_multi_parameter_cli(self, cli)
        if not result:
            result = SimpleType.parse_multi_parameter_cli(self, cli,
                                                          alternate_asa_gen_template = self.asa_key.strip() + ' %(type)s')
        return result
