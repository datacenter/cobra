'''
Created on Sep 16, 2013

Copyright (c) 2013 by Cisco Systems
@author: dli
'''
from translator.base.simpletype import SimpleType

class DMBoolean(SimpleType):
    ''' DMBoolean is translator for the type of CLI that turns on/off a particular flag, such as "logging enable'
    '''
    def __init__(self, ifc_key, asa_key, on_value, response_parser=None):
        '''
        @param on_value: str
            The value in the dictionary to turn on the feature, e.g. 'enable'
        '''
        SimpleType.__init__(self, ifc_key, asa_key, is_removable = True)
        self.on_value = on_value
        self.response_parser = response_parser

    def get_cli(self):
        assert self.has_ifc_delta_cfg()
        return self.asa_key

    def parse_cli(self, cli):
        return self.on_value

