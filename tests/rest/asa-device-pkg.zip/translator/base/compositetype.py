'''
Created on Sep 20, 2013
Copyright (c) 2013 by Cisco Systems

@author: dli
'''
import re
from simpletype import SimpleType
from translator.state_type import State, Type

class CompositeType(SimpleType):
    '''Translator for modeling ASA composite command, i.e. command with sub-commands, such as 'object network'
    '''
    def ifc2asa(self, no_asa_cfg_stack,  asa_cfg_list):
        '''Override the default implementation to take care of the sub-commands.
        '''
        action = self.delta_ifc_cfg_value['state']
        if action == State.DESTROY:
            'To generate the no form of the command'
            SimpleType.ifc2asa(self, no_asa_cfg_stack, asa_cfg_list)
            return

        'Generate CLIs from the children'
        for child in self.children.values():
            child.mode_command = self.get_cli()
            child.ifc2asa(no_asa_cfg_stack, asa_cfg_list)

    def diff_ifc_asa(self, cli):
        'Override the default implementation to take care of the children'
        SimpleType.diff_ifc_asa(self, cli)

        action = self.delta_ifc_cfg_value['state']
        if action == State.DESTROY:
            return

        for cmd in cli.sub_commands:
            translator = self.get_child_translator(cmd)
            if translator:
                translator.diff_ifc_asa(cmd)

    def populate_model(self, delta_ifc_key, delta_ifc_cfg_value):
        'Override the default implementation to let the children sharing the dictionary'
        self.delta_ifc_key = delta_ifc_key
        self.delta_ifc_cfg_value = delta_ifc_cfg_value
        if 'create_asa_key' in dir(self):
            self.asa_key = self.create_asa_key()

        for child in self.children.values():
            child.populate_model(delta_ifc_key, delta_ifc_cfg_value)

    def get_translator(self, cli):
        'Override the default implementation, as we don not need go down to the children'
        if self.is_my_cli(cli):
            return self
        else:
            return None

    def get_child_translator(self, cli):
        'Get translator for the given sub-command cli'
        for child in self.children.values():
            if 'get_translator' in dir(child):
                result = child.get_translator(cli)
                if result:
                    return result
        return None

    def is_the_same_cli(self, cli):
        'Override default implementation to compare sub-commands with those of the children'
        if cli.command != self.get_cli():
            return False
        'check the sub-commands, order is not important'
        return set(cli.sub_commands) ==  set([str(child.get_cli()) for child in self.children.values()])


class SubCommand(SimpleType):
    'Modeling sub-command'
    def __init__(self, ifc_key, asa_key, asa_gen_template = None):
        return SimpleType.__init__(self, ifc_key, asa_key, asa_gen_template)

    def get_action(self):
        'Override the default implementation to get action from the configuration dictionary entry for this sub-command'
        names = re.compile('%\((\S+)\)s').findall(self.asa_gen_template)
        states = filter(lambda x: x != None, [self.get_state_for_entry(name) for name in names])
        if not states: #the entry is into in the configuration
            return State.DESTROY
        for s in [State.NOCHANGE, State.CREATE, State.DESTROY]:
            if all([state == s for state in states]):
                return s
        return State.MODIFY

    def set_action(self, state):
        'Override the default implementation to work on the dictionary entry for this sub-command'
        names = re.compile('%\((\S+)\)s').findall(self.asa_gen_template)
        for name in names:
            value = self.get_value_for_entry(name)
            if value:
                value['state'] = state

    def get_value_for_entry(self, entry_name):
        for (kind, name, instance), value in self.delta_ifc_cfg_value['value'].iteritems():
            if entry_name == name:
                return value
        return None

    def get_state_for_entry(self, name):
        '''
        @param name: str, the name of a entry in the IFC configuration dictionary
        @return the value "state" in the IFC configuration dictionary for the named field
        '''
        value = self.delta_ifc_cfg_value['value'].get((Type.PARAM, name, ''))
        if not value:
            value = self.delta_ifc_cfg_value['value'].get((Type.FOLDER, name, ''))
        if value:
            return value['state']
        else:
            return None

    def set_config_entry(self, name, entry_state, entry_value):
        '''
        @param name: str, the name of a entry in the IFC configuration dictionary
        @param entry_state: State to set
        @param entry_value: value to set
        '''
        assert not isinstance(entry_value, dict)
        self.delta_ifc_cfg_value['value'][(Type.PARAM, name, '')] = {'state': entry_state, 'value': entry_value}
