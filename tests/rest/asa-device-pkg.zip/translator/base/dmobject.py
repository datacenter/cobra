'''
Created on Jun 12, 2013

@author: dli

Copyright (c) 2013 by Cisco Systems
'''
from collections import OrderedDict
from asaio.cli_interaction import CLIInteraction
from translator.structured_cli import StructuredCommand
import utils.env as env
from translator.state_type import Type, State

class DMObject(object):
    '''
    dmobject is combination of DMObject, DMHolder in ASDM.
    '''

    # the ASA configuration can be in either CLI format or REST API. It is considered a "static" class variable.
    is_cli_mode = True


    def __init__(self, ifc_key = "", asa_key= ""):
        """
        Constructor
        """
        #the components as dictionary of dmobject. It is similar to that in DMHashCollection in ASDM.
        self.children = OrderedDict()
        #the key to identify this dmobject in the children of its parent
        self.ifc_key = ifc_key
        #the key to identify this dmobject for the ASA configuration object. It could be command prefix, or attribute name in REST API
        self.asa_key = asa_key
        #parent DMObject
        self.parent = None

    def get_key(self):
        """
        @return:
            the key for this object in the IFC model. It has similar purpose as getObjectKey() in ASDM.
        The value of the key should be the name  of the IFC's vnsParam or vnsFolder element
        """
        return self.ifc_key

    def get_asa_key(self):
        """
        @return:
            the string of the ASA configuration object to identify this object in the IFC model.
        The value of the key should be the command prefix for ASA CLI,  or the attribute name in ASA REST API.
        """
        return self.asa_key

    def register_child(self, dmobj):
        """
        Add a dmobject as a child of this dmobject.

        @param dmobj:
            input, a dmobject
        """
        self.children[dmobj.get_key()] = dmobj
        dmobj.parent = self

    def get_top(self):
        """
        Recursively traverse from child to top parent object, this is
        useful when access to other object's contents is required
        
        @return:
            the top parent object which is know as the device model
        """
        if (self.parent == None):
            return self
        else:
            return self.parent.get_top()

    def get_parent(self):
        '@return: the parent object'
        return self.parent

    def get_ancestor_by_class(self, ancestor_class):
        """
        Recursively traverse from child to top parent object looking for an
        ancestor which is an instance of the specified class.
        If found, return the object, else return None
        """
        if (self.parent == None or isinstance(self.parent, ancestor_class)):
            return self.parent
        else:
            return self.parent.get_ancestor_by_class(ancestor_class)

    def get_child(self, key):
        """
        @return:
            the child for a given key.
        @param key:
            input, a string representing the IFC key of the child dmobject
        """
        return self.children[key] if key in self.children else None

    def get_child_by_asa_key(self, asa_key):
        """
        @return:
            the child for a given ASA key.
        @param asa_key:
            input, a string representing the ASA key of the child dmobject.
            For CLI mode it is the command prefix.
            For REST API: to be determined."
        """
        for child in self.children:
            if asa_key.startswith(child.get_asa_key()):
                return child
        return None

    def get_children_count(self):
        """
        @return:
            the number of children in this dmobject.
        """
        return len(self.children)


    def populate_model(self, delta_ifc_key, delta_ifc_cfg_value):
        '''Store the ifc configuration for this object. It is used to generate ASA configuration on
        on calling ifc2asa method.

        @param delta_ifc_key: tuple
            (type, key, instance)
            Notice here that this delta_ifc_key is not the delta_ifc_key for self.children, but rather than delta_ifc_key
            for IFC delta dictionary.
            "key" field corresponds to the ifc_key to self.children dictionary.
        @param delta_ifc_cfg_value: dict
            {
            'state': state,
            'device': device,
            'connector': connector,
            'value': scalar value or config dictionary
            }
        '''

        #the following two attributes will be used by ifc2asa method to perform ifc2asa translation
        self.delta_ifc_key = delta_ifc_key
        self.delta_ifc_cfg_value = delta_ifc_cfg_value
        if not self.children:
            return

        cfg = delta_ifc_cfg_value.get('value')
        if not isinstance(cfg, dict): #terminal node
            return

        for delta_ifc_key, value in cfg.iteritems():
            kind, key, instance = delta_ifc_key
            child = self.get_child(key)
            if child:
                child.populate_model(delta_ifc_key, value)
            #else:
                #self.log('DMObject.populateModel: %s not found' % name)


    def get_ifc_delta_cfg_ancestor(self):
        '''@return the ancestor DMObject that has ifc_delta_cfg container for this DMObject.
        '''
        result = self.parent
        while result:
            if result.has_ifc_delta_cfg():
                return result
            result = result.parent

    def create_missing_ifc_delta_cfg(self):
        '''For diff_ifc_asa method to work, we need each DMObject container
        to have proper IFC dictionary entry.
        @warning: This method is invoked by translator delta engine. Please do no override
                  it in derived class unless you really know what you are doing.
        @precondition: populate_model has been called.
        '''
        if not self.children:
            return
        if  not self.has_ifc_delta_cfg():
            self.delta_ifc_key = Type.FOLDER, self.ifc_key, ''
            self.delta_ifc_cfg_value = {'state': State.NOCHANGE, 'value': {}}
            ancestor = self.get_ifc_delta_cfg_ancestor()
            if ancestor:
                ancestor.delta_ifc_cfg_value['value'][self.delta_ifc_key] =  self.delta_ifc_cfg_value
        for child in self.children.values():
            child.create_missing_ifc_delta_cfg()

    def ifc2asa(self, no_asa_cfg_stack,  asa_cfg_list):
        '''
        Generate ASA configuration from IFC configuration delta. Assume that
        the device model has already populated with IFC delta configuration
        using populate_model method.

        One uses (self.delta_ifc_key, self.delta_ifc_cfg_value) to generate ASA
        configuration.

        @param no_asa_cfg_stack: stack
            input/output, stack of ASA CLIs to contain delete commands
        @param asa_cfg_list: list
            input/output, list of ASA configurations
        '''
        for child in self.children.values():
            child.ifc2asa(no_asa_cfg_stack, asa_cfg_list)

    def is_my_cli(self, cli):
        '''Determine if a CLI matches self.asa_key
        @param cil: str or StructuredCommand
        @return boolean, True if self.asa_key matches CLI, or False
        '''
        if not self.asa_key:
            return False
        if isinstance(cli, str):
            return cli.startswith(self.asa_key)
        elif isinstance(cli, StructuredCommand):
            return cli.command.startswith(self.asa_key)

    def get_translator(self, cli):
        '''Find the DMObject within this DMOBject that can translate a CLI
        @param cli: CLI
        @return:  the DMObject that can translate the cli
        '''
        if 'create_asa_key' in dir(self):
            self.asa_key = self.create_asa_key()
        if not self.children:
            if self.is_my_cli(cli):
                return self
            else:
                return None
        for child in self.children.values():
            if 'get_translator' in dir(child):
                result = child.get_translator(cli)
                if result:
                    return result
        return None


    def has_ifc_delta_cfg(self):
        '''Determine if there is IFC delta configuration for this class
        @return: boolean
            True if there is IFC delta configuration, otherwise False.
        '''
        if 'delta_ifc_cfg_value' not in self.__dict__:
            return False;
        if 'delta_ifc_key' not in self.__dict__:
            return False;
        if self.delta_ifc_cfg_value == None or self.delta_ifc_key == None:
            return False;
        return True

    def generate_cli(self, asa_cfg_list, cli, model_key=None):
        '''Append the given cli to asa_cfg_list. It is similar to DMObject.generateCommand(cliHolder, cli) in ASDM.
        @param asa_cfg_list: list
        @param cli: str
        @param model_key The key in the device model that is related to this CLI.
                         It's used to report errors for this CLI.

        If a class derived from dmobject has attributes of 'mode_command',
        'response_parser', or 'mode_response_parser', they will be used for the
        CLIInteraction parameters.  This can be used to set the mode command for
        all the generated CLI.

        The following example will generate the sub-commands for an interface:
        self.mode_command = 'interface Port-channel2.20'
        self.generate_cli(asa_cfg_list, 'no shutdown')
        self.generate_cli(asa_cfg_list, 'nameif external_Conn1')
        self.generate_cli(asa_cfg_list, 'ip address 20.20.20.20 255.255.255.128')
        '''

        params = {}
        for key in ('mode_command', 'response_parser', 'mode_response_parser'):
            if key in self.__dict__:
                params[key] = self.__dict__[key]
        clii = CLIInteraction(cli, model_key=model_key, **params)
        asa_cfg_list.append(clii)


    def log(self, msg):
        """
        Print a msg for debugging purpose.
        @param msg: str
            input, a text string
        """
        env.debug(msg)
