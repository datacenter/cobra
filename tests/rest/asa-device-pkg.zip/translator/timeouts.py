'''
Created on Jul 1, 2013

@author: dli

Copyright (c) 2013 by Cisco Systems
'''

from base.dmobject import DMObject
from base.simpletype import SimpleType
from translator.structured_cli import StructuredCommand

class Timeouts(DMObject):
    '''
    This is for various timeout configurations.
    Global Timeout section correspond to ASDM's Firewall>Advanced>Global Timeout screen.
    It is for all the "timeout " commands.
    '''


    def __init__(self):
        '''
        Constructor
        '''
        DMObject.__init__(self, ifc_key = Timeouts.__name__, asa_key = 'timeout')

        '@todo add a default column'
        ifc_asa_keys = [# IFC Key                    ASA Key                           Default
                        ("Connection",              "timeout conn",                   '01:00:00'),
                        ("HalfClosedConnection",    "timeout half-closed",            '00:10:00'),
                        ("Udp",                     "timeout udp",                    '0:02:00'),
                        ("Icmp",                    "timeout icmp",                   '0:00:02'),
                        ("H323",                    "timeout 323",                    '0:05:00'),
                        ("H225",                    "timeout 225",                    '1:00:00'),
                        #Trailing space in the ASA key for Mgcp is to avoid collision with mgcp-pat
                        ("Mgcp",                    "timeout mgcp ",                   '0:05:00'),
                        ("MgcpPat",                 "timeout mgcp-pat",               '0:05:00'),
                        ("TcpProxyReassembly",      "timeout tcp-proxy-reassembly",   '0:01:00'),
                        ("FloatingConn ",           "timeout floating-conn",          '0:0:0'),
                        ("SunRpc",                  "timeout sunrpc",                 '00:10:00'),
                        #Trailing space in the ASA key for Sip is to avoid collision with other sip-* command
                        ("Sip",                     "timeout sip ",                    '0:30:00'),
                        ("SipMedia",                "timeout sip_media",              '0:02:00'),
                        ("SipProvisionalMedia",     "timeout sip-provisional-media",  '0:02:00'),
                        ("SipInvite",               "timeout sip-invite",             '0:1:0'),
                        ("SipDisconnect",           "timeout sip-disconnect",         '0:2:0'),
                        ("Xlat",                    "timeout xlat",                   '3:00:00'),
                        ("PatXlate",                "timeout pat-xlate",              '0:00:30')
        ]

        for (ifc, asa, dflt) in ifc_asa_keys:
            self.register_child(SimpleType(ifc, asa, defaults = dflt))

        self.register_child(AuthenticationTimeout("AuthenAbsolute",   "absolute"))
        self.register_child(AuthenticationTimeout("AuthenInactivity", "inactivity"))

    def ifc2asa(self, no_asa_cfg_stack,  asa_cfg_list):
        'Override default implementation to deal with "no timeout ...", which is not accepted by ASA. Use "clear config timeout" instead'
        tmp_no_asa_cfg_stack = []
        result = DMObject.ifc2asa(self, tmp_no_asa_cfg_stack, asa_cfg_list)
        if tmp_no_asa_cfg_stack:
            'consolidate "no timeout ..." commands into "clear config timeout"'
            self.generate_cli(no_asa_cfg_stack, "clear config timeout")
        return result

    def get_translator(self, cli):
        ''' Override default implementation because reconcile the difference the representation of
        CLI for timeout command on ASA and our assumption here. We assume the CLI is of the form:
            timeout conn <value>
            timeout half-closed <value>
        However, on ASA, they are stored in compact form:
            timeout conn 1:00:00 half-closed 0:10:00
        '''
        if isinstance(cli, str) and cli.strip().startswith(self.asa_key):
            return self
        elif isinstance(cli, StructuredCommand) and cli.command.startswith(self.asa_key):
            return self
        return None

    def get_child_translator(self, cli):
        ''' Override default implementation because reconcile the difference the representation of
        CLI for timeout command on ASA and our assumption here. We assume the CLI is of the form:
            timeout conn <value>
            timeout half-closed <value>
        However, on ASA, they are stored in compact form:
            timeout conn 1:00:00 half-closed 0:10:00
        '''
        for child in self.children.values():
            result = child.get_translator(cli)
            if result:
                return result
        return None

    def diff_ifc_asa(self, cli):
        '''Override the default implementation in order to simplify the code by turning CLI of the form:
               timeout conn 1:00:00 half-closed 0:10:00 udp 0:02:00 icmp 0:00:02
           into
               timeout conn 1:00:00
               timeout half-closed 0:10:00
               timeout udp 0:02:00
               timeout icmp 0:00:02
        '''
        assert cli.strip().startswith(self.asa_key)

        clis = self.normalize_cli(cli)
        if not clis:
            return
        for cmd in clis:
            translator = self.get_child_translator(cmd)
            if translator:
                translator.diff_ifc_asa(cmd)

    def normalize_cli(self, cli):
        '''Override the default implementation in order to simplify the code by turning CLI of the form:
               timeout conn 1:00:00 half-closed 0:10:00 udp 0:02:00 icmp 0:00:02
           into
               timeout conn 1:00:00
               timeout half-closed 0:10:00
               timeout udp 0:02:00
               timeout icmp 0:00:02
            @param cli: str
                string of the compact form: e.g.
                   timeout conn 1:00:00 half-closed 0:10:00 udp 0:02:00 icmp 0:00:02
            @return list of strings in normal forms, such as:
                   timeout conn 1:00:00
                   timeout half-closed 0:10:00
                   timeout udp 0:02:00
                   timeout icmp 0:00:02
        '''
        tokens = cli.split()[1:]
        pos = 0
        result = []
        while True:
            if tokens[pos] == 'uauth':#'uauth' command has three tokens
                sub_cmd = ' '.join([self.asa_key, tokens[pos], tokens[pos+1], tokens[pos+2]])
                pos += 3
            else:#others have two tokens respectively
                sub_cmd = ' '.join([self.asa_key, tokens[pos], tokens[pos+1]])
                pos += 2
            result.append(sub_cmd)
            if pos >= len(tokens):
                break;
        return result


class AuthenticationTimeout(SimpleType):
    def __init__(self, ifc_key, asa_cli_suffix):
        '''
        Constructor
        '''
        SimpleType.__init__(self, ifc_key, "timeout uauth", asa_gen_template = "timeout uauth %s " + asa_cli_suffix, defaults = ' 0:05:00')
        self.asa_suffix = asa_cli_suffix

    def get_translator(self, cli):
        'Override the default implementation as the suffix is part of the key'
        result =  SimpleType.get_translator(self, cli)
        if result:
            tokens = cli.split()
            suffix = tokens[len(tokens) - 1]
            result =  self if suffix == self.asa_suffix else None
        return result