'''
Created on Aug 27, 2013

@author: tsnguyen
'''


from translator.state_type import State, Type
from translator.base.dmobject import DMObject
from translator.base.simpletype import SimpleType
import utils.util as util
import asaio.cli_interaction as cli_interaction


class AdvancedThreatDetection(DMObject):
    '''
    Advanced Thread Detection
    Supports the following CLI:
    
    threat-detection statistics
    threat-detection statistics access-list
    threat-detection statistics host [number-of-rate {1 | 2 | 3}]
    threat-detection statistics port [number-of-rate {1 | 2 | 3}]
    threat-detection statistics protocol [number-of-rate {1 | 2 | 3}]
    
    threat-detection statistics tcp-intercept [rate-interval minutes] 
        [burst-rate attacks_per_sec] 
        [average-rate attacks_per_sec]
    '''

    THREAT_DETECTION_STATISTICS = "threat-detection statistics"
    THREAT_DETECTION_STATISTICS_TCP_INTERCEPT = "threat-detection statistics tcp-intercept"
    THREAT_DETECTION_STATISTICS_ACCESS_LIST = "threat-detection statistics access-list"
   
    
    def __init__(self):
        '''
        Constructor
        '''
        DMObject.__init__(self, AdvancedThreatDetection.__name__)
        
        self.register_child(SimpleAccessList("access_list", self.THREAT_DETECTION_STATISTICS_ACCESS_LIST, on_value="enable",
                            response_parser=cli_interaction.ignore_warning_response_parser)) 
        for opt in ['host', 'port', 'protocol']:
            self.register_child(NumberOfRateOption('AdvancedThreatDetection' + opt.title(), self.THREAT_DETECTION_STATISTICS + ' ' + opt))
            self.register_child(NumberOfRateOption('AdvancedThreatDetection' + opt.title(), self.THREAT_DETECTION_STATISTICS + ' ' + opt))
            self.register_child(NumberOfRateOption('AdvancedThreatDetection' + opt.title(), self.THREAT_DETECTION_STATISTICS + ' ' + opt))
            
        self.register_child(TcpIntercept('AdvancedThreatDetectionTcpIntercept', self.THREAT_DETECTION_STATISTICS_TCP_INTERCEPT))
        
        self.register_child(SimpleStatistics("statistics", self.THREAT_DETECTION_STATISTICS, on_value="enable",
                            response_parser=cli_interaction.ignore_warning_response_parser)) 
   
    def __repr__(self):
        return "Advanced Threat Detection"
    
class SimpleStatistics(SimpleType):
    ''' Translator for the type of CLI that turns on/off statistics
    threat-detection statistics
    '''
    def __init__(self, ifc_key, asa_key, on_value, response_parser):
        '''
        @param on_value: str
            The value in the dictionary to turn on the feature, e.g. 'enable'
        '''
        SimpleType.__init__(self, ifc_key, asa_key)
        self.on_value = on_value
        self.response_parser = response_parser

    def get_cli(self):
        '''Override get_cli'''
        assert self.has_ifc_delta_cfg()
        config = util.normalize_param_dict(self.delta_ifc_cfg_value['value'])
       
        if not config:
            return ''
        if str(config).startswith('disable'):
            return 'no ' + self.asa_key
        return self.asa_key

    def parse_cli(self, cli):
        '''Override parse_cli'''
        
        if cli.endswith('statistics'):
            return 'disable' if cli.startswith('no') else self.on_value
        return cli
    
class SimpleAccessList(SimpleType):
    ''' Translator for the type of CLI that turns on/off statistics access-list
    threat-detection statistics access-list
    '''
    def __init__(self, ifc_key, asa_key, on_value, response_parser):
        '''
        @param on_value: str
            The value in the dictionary to turn on the feature, e.g. 'enable'
        '''
        SimpleType.__init__(self, ifc_key, asa_key)
        self.on_value = on_value
        self.response_parser = response_parser

    def get_cli(self):
        '''Override get_cli'''
        assert self.has_ifc_delta_cfg()
        config = util.normalize_param_dict(self.delta_ifc_cfg_value['value'])
        
        if not config:
            return ''
        
        if str(config).startswith('disable'):
            return 'no ' + self.asa_key
        return self.asa_key

    def parse_cli(self, cli):
        '''Override parse_cli'''
       
        if cli.endswith('access-list'):
            return 'disable' if cli.startswith('no') else self.on_value
        return ''
       
class NumberOfRateOption(SimpleType):
    ''' Class to support CLI
    threat-detection statistics host [number-of-rate {1 | 2 | 3}]
    threat-detection statistics port [number-of-rate {1 | 2 | 3}]
    threat-detection statistics protocol [number-of-rate {1 | 2 | 3}]
    '''
    def __init__(self, name, asa_key):
        '''Constructor'''
        self.stat_type = name[len('AdvancedThreatDetection'):].lower()
        
        SimpleType.__init__(self, name, asa_key,
            response_parser = cli_interaction.ignore_warning_response_parser)
        
    def get_cli(self):
        '''Generate the CLI for this single config.
        '''
        assert self.has_ifc_delta_cfg()
        
        config = util.normalize_param_dict(self.delta_ifc_cfg_value['value'])
        if not config:
            return ''
        result = AdvancedThreatDetection.THREAT_DETECTION_STATISTICS
        status = config.get('status')
        
        
        if status and status.startswith('disable'):
            return 'no ' + AdvancedThreatDetection.THREAT_DETECTION_STATISTICS + ' ' + self.stat_type
        result +=  ' ' + self.stat_type
            
        rate = config.get('number_of_rate')
        if rate:
            result +=  ' number-of-rate ' + str(rate)
        return result
    
    
    
    def parse_multi_parameter_cli(self, cli, alternate_asa_gen_template = None):
        '''
        Override the default implementation in case the CLI does not match asa_gen_template due to optional parameter
        '''
        # Take care of the mandatory parameters
        result = SimpleType.parse_multi_parameter_cli(self, cli, alternate_asa_gen_template = self.asa_gen_template)
       
        #Take care of the optional parameters
        tokens = cli.split()

        if tokens[0] == 'no':
            result = {(Type.PARAM, 'status', '') : {'state': State.NOCHANGE, 'value': 'disable'}}
            return result
        
        # The number of mandatory parameters is 3, i.e. 'threat-detection statistics host'
        if len(tokens) == 3:
            return result # no optional parameter

        
        
        option = tokens[3:]
        if 'number-of-rate' in option:
            pos = option.index('number-of-rate') + 1
            result = {(Type.PARAM, 'number_of_rate', '') : {'state': State.NOCHANGE, 'value': option[pos]}}
        else:
            return result
       
        return result   
    
class TcpIntercept(SimpleType):
    ''' Class to support CLI:
    threat-detection statistics tcp-intercept [rate-interval minutes] 
        [burst-rate attacks_per_sec] 
        [average-rate attacks_per_sec]
        '''
    
    def __init__(self, name, asa_key):
        '''Constructor '''
        SimpleType.__init__(self, name, asa_key,
            response_parser = cli_interaction.ignore_warning_response_parser)
    

    def get_cli(self):
        '''Generate the CLI for this single config.
        '''
        assert self.has_ifc_delta_cfg()
       
        
        config = util.normalize_param_dict(self.delta_ifc_cfg_value['value'])
        
        if not config:
            return ''
        if not isinstance(config, dict):
            if self.delta_ifc_cfg_value['state'] == State.DESTROY:
                return self.asa_key
            return ''
        status = config.get('status')
        if status and status.startswith('disable'):
            return 'no ' + AdvancedThreatDetection.THREAT_DETECTION_STATISTICS_TCP_INTERCEPT
        rate_interval = config.get('rate_interval')
        burst_rate = config.get('burst_rate')
        average_rate = config.get('average_rate')
        
        result = AdvancedThreatDetection.THREAT_DETECTION_STATISTICS_TCP_INTERCEPT
        if rate_interval:
            result +=  ' rate-interval ' + str(rate_interval)
        if burst_rate:
            result +=  ' burst-rate ' + str(burst_rate)
        if average_rate:
            result +=  ' average-rate ' + str(average_rate)
       
        return result

    def create_asa_key(self):
        '''Create the the asa key identifies this object
        @return str
        '''
        if not self.has_ifc_delta_cfg():
            return None

        value = util.normalize_param_dict(self.delta_ifc_cfg_value['value'])
        asa_key = AdvancedThreatDetection.THREAT_DETECTION_STATISTICS_TCP_INTERCEPT
        
        if 'rate_interval' in value:
            asa_key += ' rate-interval ' + str(value['rate_interval'])
        if 'burst_rate' in value:
            asa_key += ' burst-rate ' + str(value['burst_rate'])
        if 'average_rate' in value:
            asa_key += ' average-rate ' + str(value['average_rate'])
        return asa_key
    
    def parse_multi_parameter_cli(self, cli, alternate_asa_gen_template = None):
        '''
        Override the default implementation in case the CLI does not match asa_gen_template due to optional parameter
        '''
       
        # Take care of the mandatory parameters
        result = SimpleType.parse_multi_parameter_cli(self, cli, alternate_asa_gen_template = self.asa_gen_template)

        #Take care of the optional parameters
        tokens = cli.split()

        # The number of mandatory parameters is 3, i.e. 'threat-detection statistics tcp-intercept'
        if len(tokens) == 3:
            return result # no optional parameter

        for name  in ['rate_interval', 'burst_rate', 'average_rate']:
            result[(Type.PARAM, name, '')] = {'state': State.NOCHANGE, 'value': ''}

        option = tokens[3:]
        if 'rate_interval' in option: 
            pos = option.index('rate_interval')
            result[Type.PARAM, 'rate_interval', '']['value'] = option[pos]
        if 'burst_rate' in option: 
            pos = option.index('burst_rate')
            result[Type.PARAM, 'burst_rate', '']['value'] = option[pos]
        if 'average_rate' in option: 
            pos = option.index('average_rate')
            result[Type.PARAM, 'average_rate', '']['value'] = option[pos]
        return result
            
