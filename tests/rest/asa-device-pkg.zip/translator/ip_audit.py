'''
Created on Oct 2, 2013

@author: richauha

Copyright (c) 2013 by Cisco Systems
'''

from base.dmobject import DMObject
from base.simpletype import SimpleType

class IPAudit(DMObject):
    '''
    This is for basic ip audit configurations.
    IP Audit section correspond to ASDM's Firewall>Advanced>IP Audit screen.
    '''
    def __init__(self):
        '''
        Constructor
        '''
        DMObject.__init__(self, ifc_key = IPAudit.__name__, asa_key = 'ip audit')
        self.register_child(SimpleType(ifc_key='IPAuditAttack', asa_gen_template='ip audit attack action %s'))
        self.register_child(SimpleType(ifc_key='IPAuditInfo', asa_gen_template='ip audit info action %s'))

