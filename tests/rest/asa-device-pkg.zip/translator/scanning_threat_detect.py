'''
Created on Aug 27, 2013

@author: tsnguyen
'''


from translator.base.simpletype import SimpleType
import utils.util as util
from translator.base.dmobject import DMObject
from translator.state_type import Type, State


class ScanningThreatDetection(DMObject):
    '''
    Scanning Threat Detection
    Supports the following CLI:
    
    threat-detection scanning-threat [shun 
        [except {ip-address ip_address mask | object-group network_object_group_id}]]
    threat-detection scanning-threat shun duration seconds
    threat-detection rate scanning-threat 
        rate-interval rate_interval average-rate av_rate burst-rate burst_rate
    '''

    THREAT_DETECTION_SCANNING = "threat-detection scanning-threat"
    THREAT_DETECTION_SCANNING_SHUN = "threat-detection scanning-threat shun"
    THREAT_DETECTION_SCANNING_RATE = "threat-detection rate scanning-threat"
    
    def __init__(self):
        '''
        Constructor
        '''
        DMObject.__init__(self, ScanningThreatDetection.__name__)
        
        self.register_child(ShunExcept('ScanningThreatShunExceptIP', self.THREAT_DETECTION_SCANNING_SHUN + " except ip-address"))
        self.register_child(ShunExcept('ScanningThreatShunExceptObject', self.THREAT_DETECTION_SCANNING_SHUN + " except object-group"))
        self.register_child(ShunDuration('ScanningThreatShunDuration', self.THREAT_DETECTION_SCANNING_SHUN + " duration"))
        self.register_child(ScanningThreatRate('ScanningThreatRate', self.THREAT_DETECTION_SCANNING_RATE))
        self.register_child(SimpleShun('shun_status', self.THREAT_DETECTION_SCANNING_SHUN))
        self.register_child(SimpleScanning('scanning_threat', self.THREAT_DETECTION_SCANNING))

    
    def __repr__(self):
        return "Scanning Threat Detection"
    
    @staticmethod   
    def ignore_msg_response_parser(response):
        'Ignores some response, otherwise returns original'
        msgs = ["already configured", "no such rate", "Can not remove", "already in except list"]
       
        if response:
            for msg in msgs:
                if msg in response:
                    return None
            return response
        else:
            return None
        
class SimpleScanning(SimpleType):
    ''' Class to support CLI
    threat-detection scanning-threat         
    '''
    def __init__(self, name, asa_key):
        '''Constructor'''
        
        SimpleType.__init__(self, name, asa_key,
            response_parser = ScanningThreatDetection.ignore_msg_response_parser)
        
    def get_cli(self):
        '''Generate the CLI for this config.
        '''
        assert self.has_ifc_delta_cfg()
        
        status = util.normalize_param_dict(self.delta_ifc_cfg_value['value'])
        
        if status and str(status).startswith('disable'):
            return 'no ' + ScanningThreatDetection.THREAT_DETECTION_SCANNING
        
        return ScanningThreatDetection.THREAT_DETECTION_SCANNING    

    def parse_cli(self, cli):
        '''Override
        '''
        
        if cli.endswith(ScanningThreatDetection.THREAT_DETECTION_SCANNING):
            return 'disable' if cli.startswith('no ') else 'enable'
             
        return cli
    
class SimpleShun(SimpleType):
    ''' Class to support CLI
    threat-detection scanning-threat shun 
        
    '''
    def __init__(self, name, asa_key):
        '''Constructor'''
        
        SimpleType.__init__(self, name, asa_key,
            response_parser = ScanningThreatDetection.ignore_msg_response_parser)
        
    def get_cli(self):
        '''Generate the CLI for this 'shun' config.
        '''
        assert self.has_ifc_delta_cfg()
        
        status = util.normalize_param_dict(self.delta_ifc_cfg_value['value'])
       
        if not status:
            return ''
        if isinstance(status, dict):
            return ''
        
        if str(status).startswith('disable'):
            return 'no ' + ScanningThreatDetection.THREAT_DETECTION_SCANNING_SHUN
        elif str(status).startswith('enable'):
            return ScanningThreatDetection.THREAT_DETECTION_SCANNING_SHUN     
        
        return ScanningThreatDetection.THREAT_DETECTION_SCANNING_SHUN
            
    def parse_cli(self, cli):
        '''Override
        '''
        
        if cli.endswith(ScanningThreatDetection.THREAT_DETECTION_SCANNING_SHUN):
            return 'disable' if cli.startswith('no ') else 'enable'
             
        return 'enable'
    
class ShunDuration(SimpleType):
    ''' Class to support CLI
    threat-detection scanning-threat [shun 
        [except {ip-address ip_address mask | object-group network_object_group_id}]]
    '''
    def __init__(self, name, asa_key):
        '''Constructor'''
        
        SimpleType.__init__(self, name, asa_key,
            asa_gen_template = ScanningThreatDetection.THREAT_DETECTION_SCANNING_SHUN + ' duration %(duration)s',
            response_parser = ScanningThreatDetection.ignore_msg_response_parser)
        
    def get_cli(self):
        '''Generate the CLI for this 'shun duration' config.
        '''
        assert self.has_ifc_delta_cfg()
        
        config = util.normalize_param_dict(self.delta_ifc_cfg_value['value'])
       
        if not config:
            return ''
        if not isinstance(config, dict):
            return ''
        status = config.get('status')
        
        if status and status.startswith('disable'):
            return 'no ' + self.asa_gen_template % config
        
        return self.asa_gen_template % config
    
    
    
class ShunExcept(SimpleType):
    ''' Class to support CLI
    threat-detection scanning-threat [shun 
        [except {ip-address ip_address mask | object-group network_object_group_id}]]
    '''
    def __init__(self, name, asa_key):
        '''Constructor'''
        if name.endswith('IP'):
            self.asa_gen_template = asa_key + " %(except_ip)s %(except_mask)s"
        elif name.endswith('Object'):
            self.asa_gen_template = asa_key + " %(except_object_group)s"
        SimpleType.__init__(self, name, asa_key, asa_gen_template = self.asa_gen_template,
            response_parser = ScanningThreatDetection.ignore_msg_response_parser)
        
    def get_cli(self):
        '''Generate the CLI for this 'shun except' config.
        '''
        assert self.has_ifc_delta_cfg()
        
        config = util.normalize_param_dict(self.delta_ifc_cfg_value['value'])
        if not config:
            return ''
        
        if not isinstance(config, dict):
            return ''
        
        status = config.get('status')
        
        if status and status.startswith('disable'):
            return 'no ' + self.asa_gen_template % config
       
        return self.asa_gen_template % config
    
    def parse_multi_parameter_cli(self, cli):
        result = SimpleType.parse_multi_parameter_cli(self, cli, alternate_asa_gen_template = self.asa_gen_template)
        status = 'enable'
        if cli.startswith('no '):
            status = 'disable'
        if isinstance(result, dict):
            result[(Type.PARAM, 'status', 'status')] = {'state': State.NOCHANGE, 'value': status}
       
        return result
    
class ScanningThreatRate(SimpleType):
    ''' Class to support CLI
    threat-detection rate scanning-threat 
        rate-interval rate_interval average-rate av_rate burst-rate burst_rate
    '''
    def __init__(self, name, asa_key):
        '''Constructor'''
        
        SimpleType.__init__(self, name, asa_key,
            asa_gen_template = ScanningThreatDetection.THREAT_DETECTION_SCANNING_RATE + ' rate-interval %(rate_interval)s average-rate %(average_rate)s burst-rate %(burst_rate)s',
            response_parser = ScanningThreatDetection.ignore_msg_response_parser)
        
    def get_cli(self):
        '''Generate the CLI for this 'rate' config.
        '''
        assert self.has_ifc_delta_cfg()
       
        config = util.normalize_param_dict(self.delta_ifc_cfg_value['value'])
        if not config:
            return ''
        if not isinstance(config, dict):
            return ''
        status = config.get('status')
        
        cli = ''
        if status and status.startswith('disable'):
            cli = 'no ' + self.asa_gen_template % config
        else:
            cli = self.asa_gen_template % config
       
        return cli
    
    def parse_multi_parameter_cli(self, cli):
        result = SimpleType.parse_multi_parameter_cli(self, cli, alternate_asa_gen_template = self.asa_gen_template)
        
        if cli.startswith('no '):
            if isinstance(result, dict):
                result[(Type.PARAM, 'status', 'status')] = {'state': State.MODIFY, 'value': 'disable'}
       
        return result
