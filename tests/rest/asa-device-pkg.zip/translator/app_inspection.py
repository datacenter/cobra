'''
Created on Jul 25, 2013

@author: tsnguyen
Application Inspection Class
'''



from translator.base.dmobject import DMObject
from translator.state_type import State
from translator.base.simpletype import SimpleType

from asaio.cli_interaction import CLIInteraction
import utils.util as util



class ApplicationInspection(DMObject):
    '''
    Class for Application Inspection
    '''
    
    POLICY_MAP_CLI = "policy-map global_policy"
    CLASS_INSPECT_DEFAULT_CLI = "class inspection_default"
    
    inspections = None
    inspect_default = []
    inspect_nondefault = []
    inspect_dict = {}
    inspect_asa_cli = {}
    
    inspect_list = []
    
    ifc_asa_keys = [
                # IFC key      ASA CLI                Is a default?
                ("ctiqbe",  "inspect ctiqbe",               False), 
                ("dcerpc",  "inspect dcerpc",               False), 
                ("dns",     "inspect dns",                  True),
                ("esmtp",   "inspect esmtp",                True),
                ("ftp",     "inspect ftp",                  True),  
                ("ftp_strict","inspect ftp strict",         False),    
                ("gtp",     "inspect gtp",                  False),    
                ("h323_h225","inspect h323 h225",           True),
                ("h323_ras", "inspect h323 ras",            True),        
                ("http",    "inspect http",                 False),
                ("icmp",    "inspect icmp",                 False),
                ("icmp_error","inspect icmp error",         False),
                ("ils",     "inspect ils",                  False),
                ("ip_options","inspect ip-options",         True),
                ("ipsec_pass_thru","inspect ipsec-pass-thru",False),
                ("mgcp",    "inspect mgcp",                 False),
                ("mmp",     "inspect mmp",                  False),
                ("netbios", "inspect netbios",              True),
                ("pptp",    "inspect pptp",                 False),
                ("rsh",     "inspect rsh",                  True),
                ("rtsp",    "inspect rtsp",                 True),
                ("sip",     "inspect sip",                  True),
                ("skinny",  "inspect skinny",               True),
                ("snmp",    "inspect snmp",                 False),
                ("sqlnet",  "inspect sqlnet",               True),
                ("sunrpc",  "inspect sunrpc",               True),
                ("tftp",    "inspect tftp",                 True),
                ("waas",    "inspect waas",                 False),
                ("xdmcp",   "inspect xdmcp",                True)
                ]
    
    def __init__(self, *args, **kwargs):
        '''
        Constructor
        #args -- tuple of anonymous arguments
        #kwargs -- dictionary of named arguments
        '''
        
        DMObject.__init__(self, ApplicationInspection.__name__)
        
        self.cfg_value = None
        self.change_list = None
        
        for ifc, cli_prefix, is_default in ApplicationInspection.ifc_asa_keys:
        
            inspect = InspectElement(ifc_key=ifc, asa_key=cli_prefix, 
                                     enabled=False, default=is_default)
        
            ApplicationInspection.inspect_list.append(ifc)
            ApplicationInspection.inspect_dict[ifc] = inspect
            ApplicationInspection.inspect_asa_cli[ifc] = cli_prefix
            if is_default:   
                ApplicationInspection.inspect_default.append(ifc)
            else:
                ApplicationInspection.inspect_nondefault.append(ifc)
        
    
    def populate_model(self, delta_ifc_key, delta_ifc_cfg_value): 
        ''' Populate model '''
        if not delta_ifc_cfg_value:
            return
        
        self.cfg_value = delta_ifc_cfg_value
        self.change_list = []

        config = util.normalize_param_dict(self.cfg_value['value'])
       
        for ifc_key, value in config.iteritems():
            self.inspect_dict[ifc_key].enabled = value.startswith('enable') 
            self.change_list.append(ifc_key)
           
        
        
    def ifc2asa(self, no_asa_cfg_stack, asa_cfg_list):
        ''' Translate IFC config to ASA config  '''
        if not self.cfg_value:
            return
        
        for key in self.change_list:
            inspect = self.inspect_dict.get(key)
            inspect.ifc2asa(no_asa_cfg_stack, asa_cfg_list)
                
    
    
    def __str__(self):
        return "Application Inspection "
       
            
    def __repr__(self):
        return "Application Inspection "
    

               
class InspectElement(SimpleType):
    '''Inspection Element class '''
    
    def __init__(self, *args, **kwargs):
        ''' Constructor '''
        
        
        self.is_default = kwargs.get('default')
        self.ifc_key = kwargs.get('ifc_key')
        
        self.asa_cli_prefix = kwargs.get('asa_key')
        self.enabled = kwargs.get('enabled')
            
        try:
            key = kwargs['key']
            self.state = key[0]
        except KeyError:
            self.state = State.CREATE
            
        
        SimpleType.__init__(self, ifc_key = self.ifc_key, asa_key = self.asa_cli_prefix)


        
    def ifc2asa_destroy(self, no_asa_cfg_stack, asa_cfg_list):
        ''' IFC to ASA destroy '''
        self.generate_cli(no_asa_cfg_stack, self.generate_single_cli(False))
                
    def ifc2asa_create_modify(self, no_asa_cfg_stack, asa_cfg_list):
        ''' IFC to ASA create '''
        if self.enabled:
            self.generate_cli(asa_cfg_list, self.generate_single_cli(self.enabled))
        else: 
            self.generate_cli(no_asa_cfg_stack, self.generate_single_cli(self.enabled))
           
    
    def ifc2asa(self, no_asa_cfg_stack, asa_cfg_list):
        ''' Translate IFC config to ASA config '''
        
        if self.state == State.DESTROY:
            self.ifc2asa_destroy(no_asa_cfg_stack, asa_cfg_list)
        elif self.state == State.CREATE or self.state == State.MODIFY:
            self.ifc2asa_create_modify(no_asa_cfg_stack, asa_cfg_list)
    
        
    def populate_model(self, delta_ifc_key, delta_ifc_cfg_value): 
        ''' Populate enabled field'''
        self.enabled = delta_ifc_cfg_value
    
    
    def generate_single_cli(self, enabled):
        ''' Generate a CLI '''
        
        if enabled:
            return self.asa_cli_prefix
        else:
            return 'no ' + self.asa_cli_prefix
    

    def __str__(self):
        return "Application Inspection  enabled=" +  str(self.enabled) + " " + str(self.ifc_key) + "default=" + str(self.is_default)
    def __repr__(self):
        return "Application Inspection  enabled=" + str(self.enabled) + ' ' + str(self.ifc_key) +  "default=" + str(self.is_default)
    
    
    def generate_cli(self, asa_cfg_list, cli):
        ''' Generate complete inspect CLI '''
        clia = CLIInteraction(cli, response_parser=self.ignore_inspect_response_parser, mode_command=(ApplicationInspection.POLICY_MAP_CLI, ApplicationInspection.CLASS_INSPECT_DEFAULT_CLI))
        asa_cfg_list.append(clia) 
        
        
    @staticmethod   
    def ignore_inspect_response_parser(response):
        'Ignores some response, otherwise returns original'
        msg1 = 'Inspect configuration of this type exists'
        msg2 = 'Inspection not installed'
        msg3 = 'GTP Feature can be enabled by UPGRADING the license key'
        return None if not response or msg1 in response  or msg2 in response or msg3 in response else response
   
