'''
Copyright (c) 2013 by Cisco Systems, Inc.

@author: emilymw
'''
import re
from base.simpletype import SimpleType
from base.dmlist import DMList
from base.compositetype import CompositeType, SubCommand
from state_type import State
from utils.util import normalize_param_dict

class _ObjectNetworks(DMList):
    'Base class for the containers'
    def __init__(self, name, child_class, asa_sub_key):
        DMList.__init__(self, name, child_class, asa_key = 'object network')
        self.asa_sub_key = asa_sub_key

    def is_my_cli(self, cli):
        if isinstance(cli, str):
            return False # not handled by us
        if not cli.command.startswith(self.asa_key):
            return False
        return any(re.compile(self.asa_sub_key).match(str(cmd).strip()) for cmd in  cli.sub_commands)

class HostObjects(_ObjectNetworks):
    'Container for HostObject'
    def __init__(self):
        _ObjectNetworks.__init__(self, 'HostObject', HostObject, asa_sub_key = 'host')

class RangeObjects(_ObjectNetworks):
    'Container for RangeObject'
    def __init__(self):
        _ObjectNetworks.__init__(self, 'RangeObject', RangeObject, asa_sub_key = 'range')

class SubnetObjects(_ObjectNetworks):
    'Container for SubnetObject'
    def __init__(self):
        _ObjectNetworks.__init__(self, 'SubnetObject', SubnetObject, asa_sub_key = 'subnet')

class FQDNObjects(_ObjectNetworks):
    'Container for FQDNObject'
    def __init__(self):
        _ObjectNetworks.__init__(self, 'FQDNObject', FQDNObject, asa_sub_key = 'fqdn')



class _ObjectNetwork(CompositeType):
    '''Base class 'object network' CLI object. This is the base type for all rest classes in this module
    '''
    def __init__(self, name):
        SimpleType.__init__(self, name,
                            asa_gen_template='object network %(name)s');
        self.register_child(Description())

    def create_asa_key(self):
        return self.get_cli()


class HostObject(_ObjectNetwork):
    '''Model after 'object network\n host' object
    '''
    def __init__(self, name):
        _ObjectNetwork.__init__(self, name);
        self.register_child(SubCommand(ifc_key = '', asa_key = 'host',
                                       asa_gen_template = 'host %(ip_address)s'))


class SubnetObject(_ObjectNetwork):
    '''Model after 'object network\n subnet' object
    '''
    def __init__(self, name):
        _ObjectNetwork.__init__(self, name);
        self.register_child(SubCommand(ifc_key = '', asa_key = 'subnet',
                                       asa_gen_template = 'subnet %(ip_address)s %(ip_mask)s'))

class RangeObject(_ObjectNetwork):
    '''Model after 'object network\n range" object
    '''
    def __init__(self, name):
        _ObjectNetwork.__init__(self, name);
        self.register_child(SubCommand(ifc_key = '', asa_key = 'range',
                                       asa_gen_template = 'range %(from_address)s %(to_address)s'))


class FQDNObject(_ObjectNetwork):
    '''Model after 'object network\n fqdn" object
    '''
    def __init__(self, name):
        _ObjectNetwork.__init__(self, name);
        self.register_child(SubCommand(ifc_key = '', asa_key = 'range',
                                       asa_gen_template = 'fqdn v%(version)s %(hostname)s'))

class Description(SubCommand):
    'Translator for description sub-command'
    def __init__(self):
        SubCommand.__init__(self, ifc_key = 'description',
                            asa_key = 'description',
                            asa_gen_template = 'description %(description)s')

    def get_cli(self):
        'Override the default implementation to take care of the case when the field is absent from the dictionary'
        value = normalize_param_dict(self.delta_ifc_cfg_value['value'])
        if not value.get(self.ifc_key):
            return self.asa_key
        else:
            return SubCommand.get_cli(self)

    def parse_cli(self, cli):
        'Override default implementation because the value is multiple words'
        if cli.strip() == self.asa_key:
            return ''
        return cli[cli.index(' ')+1:]

    def diff_ifc_asa(self, cli):
        SubCommand.diff_ifc_asa(self, cli)
        'Take care of the case where the field is not set in IFC configuration but set in the device'
        if self.get_cli().strip() == self.asa_key and cli != self.asa_key:
            self.set_config_entry(self.ifc_key, State.DESTROY, self.parse_cli(cli))
