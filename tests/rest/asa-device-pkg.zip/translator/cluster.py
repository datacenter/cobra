'''
Created on Sep 25, 2013

@author: feliu
'''

from translator.base.dmobject import DMObject
from translator.base.dmlist import DMList
from translator.base.simpletype import SimpleType
from translator.base.dmboolean import DMBoolean
import utils.util as util
from asaio.cli_interaction import CLIInteraction
from translator.state_type import Type, State
import re

class ClusterConfig(DMObject):
    '''
    This class represents the holder of all cluster configuration.
    '''

    def __init__(self):
        DMObject.__init__(self, ClusterConfig.__name__)
        self.register_child(ClusterRole('cluster_master'))
#         ifc_asa_keys = (
#                         ("lan_unit",          "cluster lan unit"),
#                         ("key_secret",        "cluster key"),
#                         ("key_in_hex",        "cluster key hex"),
#                         ("interface_policy",  "cluster interface-policy"),
#                         ("monitor_interface", "monitor-interface")
#                         )
#         for ifc, asa in ifc_asa_keys:
#             self.register_child(SimpleType(ifc, asa, response_parser=cluster_response_parser))
#         self.register_child(DMBoolean('http_replication', 'cluster replication http', on_value="enable",
#                             response_parser=cluster_response_parser))
#         self.register_child(DMList('cluster_lan_interface', ClusterLANInterface, asa_key='cluster lan interface'))
#         self.register_child(DMList('cluster_link_interface', ClusterLinkInterface, asa_key='cluster link'))
#         self.register_child(DMList('cluster_ip', ClusterIP, asa_key='cluster interface ip'))
#         self.register_child(DMList('polltime', ClusterPolltime, asa_key='cluster polltime'))
#         self.register_child(DMList('mac_address', ClusterMacAddress, asa_key='cluster mac address'))
#         self.response_parser = cluster_response_parser
#         self.register_child(DMBoolean(ifc_key = "cluster", asa_key = "cluster", on_value="enable",
#                             response_parser=cluster_response_parser))

class ClusterRole(DMObject):
    '''
    This class represents the cluster role declaration.
    '''

    def __init__(self, name):
        DMObject.__init__(self, name)
        
    def ifc2asa(self, no_asa_cfg_stack, asa_cfg_list):
        print self

class ClusterLANInterface(SimpleType):
    '''
    This class represents the holder of cluster LAN-based interface configuration.
    '''

    def __init__(self, name):
        SimpleType.__init__(self, name,
                            asa_gen_template='cluster lan interface %(interface_name)s %(interface)s',
                            response_parser = cluster_response_parser)

    def ifc2asa(self, no_asa_cfg_stack, asa_cfg_list):
        '''Generate ASA configuration from IFC configuration delta.
        '''

        if not self.has_ifc_delta_cfg():
            return
        action = self.delta_ifc_cfg_value['state']
        if action == State.NOCHANGE:
            return

        if self.is_cli_mode:
            if action in (State.CREATE, State.MODIFY):
                self.generate_cli(asa_cfg_list, self.get_cli())
                config = util.normalize_param_dict(self.delta_ifc_cfg_value['value'])
                mode_cmd = 'interface ' + config['interface']
                asa_cfg_list.append(CLIInteraction(command='no shutdown', mode_command=mode_cmd))
            elif action == State.DESTROY and self.is_removable:
                self.generate_cli(asa_cfg_list, 'no ' + self.get_cli())

class ClusterLinkInterface(SimpleType):
    '''
    This class represents the holder of cluster link (stateful) interface configuration.
    '''

    def __init__(self, name):
        SimpleType.__init__(self, name,
                            asa_gen_template='cluster link %(interface_name)s %(interface)s',
                            response_parser = cluster_response_parser)

    def ifc2asa(self, no_asa_cfg_stack, asa_cfg_list):
        '''Generate ASA configuration from IFC configuration delta.
        '''

        if not self.has_ifc_delta_cfg():
            return
        action = self.delta_ifc_cfg_value['state']
        if action == State.NOCHANGE:
            return

        if self.is_cli_mode:
            if action in (State.CREATE, State.MODIFY):
                self.generate_cli(asa_cfg_list, self.get_cli())
                config = util.normalize_param_dict(self.delta_ifc_cfg_value['value'])
                mode_cmd = 'interface ' + config['interface']
                asa_cfg_list.append(CLIInteraction(command='no shutdown', mode_command=mode_cmd))
            elif action == State.DESTROY and self.is_removable:
                self.generate_cli(asa_cfg_list, 'no ' + self.get_cli())

class ClusterIP(SimpleType):
    '''
    This class represents the holder of cluster IP configuration.
    '''

    def __init__(self, name):
        SimpleType.__init__(self, name, is_removable=True,
                            asa_gen_template='cluster interface ip %(interface_name)s %(active_ip)s',
                            response_parser = cluster_response_parser)

    def get_cli(self):
        '''Generate the CLI for this single cluster ip config.
        '''
        assert self.has_ifc_delta_cfg()
        config = util.normalize_param_dict(self.delta_ifc_cfg_value['value'])
        netmask = config.get('netmask') if ':' not in config.get('active_ip') else ''
        standby_ip = config.get('standby_ip')
        result = SimpleType.get_cli(self)
        result += ' ' + netmask + ' standby ' + standby_ip
        return ' '.join(result.split())

    def create_asa_key(self):
        '''Create the the asa key identifies this object
        @return str
        '''
        assert self.has_ifc_delta_cfg()
        value = util.normalize_param_dict(self.delta_ifc_cfg_value['value'])
        return self.asa_gen_template % value

    def parse_multi_parameter_cli(self, cli):
        '''
        Override the default implementation in case the CLI does not match asa_gen_template due to optional parameter
        '''
        # Take care of the mandatory parameters
        result = SimpleType.parse_multi_parameter_cli(self, cli, alternate_asa_gen_template = self.asa_gen_template)

        'Take care of the optional parameters'
        tokens = cli.split()

        # The number of mandatory parameters is 3, i.e. 'cluster interface ip'
        if len(tokens) == 3:
            return result # no optional parameter

        for name  in ['interface_name', 'active_ip', 'standby_ip']:
            result[(Type.PARAM, name, '')] = {'state': State.NOCHANGE, 'value': ''}
        option = tokens[3:]
        # for ipv4, option is: %(interface_name)s %(active_ip)s %(netmask)s standby %(standby_ip)s
        # for ipv6, option is: %(interface_name)s %(active_ip)s standby %(standby_ip)s
        result[Type.PARAM, 'interface_name', '']['value'] = option[0]
        result[Type.PARAM, 'active_ip', '']['value'] = option[1]
        if ':' not in option[1]: # ipv4
            result[(Type.PARAM, 'netmask', '')] = {'state': State.NOCHANGE, 'value': ''}
            result[Type.PARAM, 'netmask', '']['value'] = option[2]
            # skip option[3], which should be the 'standby' keyword
            result[Type.PARAM, 'standby_ip', '']['value'] = option[4]
        else: # ipv6, no netmask
            # skip option[2], which should be the 'standby' keyword
            result[Type.PARAM, 'standby_ip', '']['value'] = option[3]
        return result

class ClusterPolltime(SimpleType):
    '''
    This class represents the holder of cluster polltime configuration.
    '''

    def __init__(self, name):
        SimpleType.__init__(self, name,
                            asa_gen_template='cluster polltime',
                            response_parser = cluster_response_parser)

    def get_cli(self):
        '''Generate the CLI for the cluster polltime config.
        '''

        assert self.has_ifc_delta_cfg()
        config = util.normalize_param_dict(self.delta_ifc_cfg_value['value'])
        unit_or_interface = config.get('unit_or_interface')
        unit_or_interface = ' ' + unit_or_interface if unit_or_interface else ''
        interval_in_second = config.get('interval_in_second')
        interval_in_second = ' ' + interval_in_second if interval_in_second else ''
        interval_in_msec = config.get('interval_in_msec')
        interval_in_msec = ' msec ' + interval_in_msec if interval_in_msec else ''
        holdtime_in_second = config.get('holdtime_in_second')
        holdtime_in_second = ' holdtime ' + holdtime_in_second if holdtime_in_second else ''
        holdtime_in_msec = config.get('holdtime_in_msec')
        holdtime_in_msec = ' holdtime msec ' + holdtime_in_msec if holdtime_in_msec else ''
        return 'cluster polltime' + unit_or_interface + interval_in_second + \
                interval_in_msec + holdtime_in_second + holdtime_in_msec

    def create_asa_key(self):
        '''Create the the asa key identifies this object
        @return str
        '''
        assert self.has_ifc_delta_cfg()
        value = util.normalize_param_dict(self.delta_ifc_cfg_value['value'])
        return self.asa_gen_template % value

    def parse_cli(self, cli):
        '''
        Discover the value for this object from given CLI
        '''
        # Valid examples:
        # 1.  cluster polltime 5
        # 2.  cluster polltime 5 holdtime 15
        # 3.  cluster polltime msec 200
        # 4.  cluster polltime msec 200 holdtime 1
        # 5.  cluster polltime msec 200 holdtime msec 800
        # 6.  cluster polltime interface|unit 5
        # 7.  cluster polltime interface|unit 5 holdtime 15
        # 8.  cluster polltime interface|unit msec 200
        # 9.  cluster polltime interface|unit msec 200 holdtime 1
        # 10. cluster polltime interface|unit msec 200 holdtime msec 800

        p1 = re.compile('^cluster polltime \d+$')
        p2 = re.compile('^cluster polltime \d+ holdtime \d+$')
        p3 = re.compile('^cluster polltime msec \d+$')
        p4 = re.compile('^cluster polltime msec \d+ holdtime \d+$')
        p5 = re.compile('^cluster polltime msec \d+ holdtime msec \d+$')
        p6 = re.compile('^cluster polltime (interface|unit) \d+$')
        p7 = re.compile('^cluster polltime (interface|unit) \d+ holdtime \d+$')
        p8 = re.compile('^cluster polltime (interface|unit) msec \d+$')
        p9 = re.compile('^cluster polltime (interface|unit) msec \d+ holdtime \d+$')
        p10= re.compile('^cluster polltime (interface|unit) msec \d+ holdtime msec \d+$')

        index_unit_or_interface = None
        index_interval_in_second = None
        index_interval_in_msec = None
        index_holdtime_in_second = None
        index_holdtime_in_msec = None

        if p1.match(cli):   # cluster polltime 5
            index_interval_in_second = 2
        elif p2.match(cli): # cluster polltime 5 holdtime 15
            index_interval_in_second = 2
            index_holdtime_in_second = 4
        elif p3.match(cli): # cluster polltime msec 200
            index_interval_in_msec = 3
        elif p4.match(cli): # cluster polltime msec 200 holdtime 1
            index_interval_in_msec = 3
            index_holdtime_in_second = 5
        elif p5.match(cli): # cluster polltime msec 200 holdtime msec 800
            index_interval_in_msec = 3
            index_holdtime_in_msec = 6
        elif p6.match(cli): # cluster polltime interface|unit 5
            index_unit_or_interface = 2
            index_interval_in_second = 3
        elif p7.match(cli): # cluster polltime interface|unit 5 holdtime 15
            index_unit_or_interface = 2
            index_interval_in_second = 3
            index_holdtime_in_second = 5
        elif p8.match(cli): # cluster polltime interface|unit msec 200
            index_unit_or_interface = 2
            index_interval_in_msec = 4
        elif p9.match(cli): # cluster polltime interface|unit msec 200 holdtime 1
            index_unit_or_interface = 2
            index_interval_in_msec = 4
            index_holdtime_in_second = 6
        elif p10.match(cli):# cluster polltime interface|unit msec 200 holdtime msec 800
            index_unit_or_interface = 2
            index_interval_in_msec = 4
            index_holdtime_in_msec = 7

        tokens = cli.split()
        result = {}
        if index_unit_or_interface:
            result[(Type.PARAM, 'unit_or_interface', '')] = {'state': State.NOCHANGE, 'value': ''}
            result[Type.PARAM, 'unit_or_interface', '']['value'] = tokens[index_unit_or_interface]
        if index_interval_in_second:
            result[(Type.PARAM, 'interval_in_second', '')] = {'state': State.NOCHANGE, 'value': ''}
            result[Type.PARAM, 'interval_in_second', '']['value'] = tokens[index_interval_in_second]
        if index_interval_in_msec:
            result[(Type.PARAM, 'interval_in_msec', '')] = {'state': State.NOCHANGE, 'value': ''}
            result[Type.PARAM, 'interval_in_msec', '']['value'] = tokens[index_interval_in_msec]
        if index_holdtime_in_second:
            result[(Type.PARAM, 'holdtime_in_second', '')] = {'state': State.NOCHANGE, 'value': ''}
            result[Type.PARAM, 'holdtime_in_second', '']['value'] = tokens[index_holdtime_in_second]
        if index_holdtime_in_msec:
            result[(Type.PARAM, 'holdtime_in_msec', '')] = {'state': State.NOCHANGE, 'value': ''}
            result[Type.PARAM, 'holdtime_in_msec', '']['value'] = tokens[index_holdtime_in_msec]
        return result

class ClusterMacAddress(SimpleType):
    '''
    This class represents the holder of cluster virtual MAC address configuration.
    '''

    def __init__(self, name):
        SimpleType.__init__(self, name, is_removable=True,
                            asa_gen_template='cluster mac address %(interface_name)s %(active_mac)s %(standby_mac)s',
                            response_parser = cluster_response_parser)

def cluster_response_parser(response):
    '''
    Ignores INFO, WARNING, and some expected errors in the response, otherwise returns original.
    '''

    if response:
        msgs_to_ignore = ('INFO:',
                          'WARNING:',
                          'Interface does not have virtual MAC',
                          'No change to the stateful interface',
                          'Waiting for the earlier webvpn instance to terminate',
                          'This unit is in syncing state',
                          'Configuration syncing is in progress')
        found_msg_to_ignore = False
        for msg in msgs_to_ignore:
            if msg in response:
                found_msg_to_ignore = True
    return None if response and found_msg_to_ignore else response
