'''
Created on Jun 12, 2013

@author: dli
Copyright (c) 2013 by Cisco Systems

'''
from asaio.cli_interaction import format_cli
from utils.util import set_cfg_state, massage_param_dict
from state_type import Type, State

from base.dmobject import DMObject
from base.dmlist import DMList

from rule.access_rule import AccessGroup, AccessGroupGlobal, AccessList
from timeouts import Timeouts

from static_route import IntStaticRoute, ExtStaticRoute
from logging import LoggingConfig
from failover import FailoverConfig

from app_inspection import ApplicationInspection
from basic_threat_detect import BasicThreatDetection
from advanced_threat_detect import AdvancedThreatDetection
from scanning_threat_detect import ScanningThreatDetection

from connector import Vif, Vlan, EncapAss, IPAddress
from connector import ExIntfConfigRelFolder, InIntfConfigRelFolder, Connectors, Connector
from network_object import HostObjects, FQDNObjects, RangeObjects, SubnetObjects
from service_object import ICMP4Objects, ICMP6Objects, ProtocolObjects, TCPObjects, UDPObjects
from ip_audit import IPAudit

def ifc2asa(ifc_delta_cfg_dict):
    '''Generate ASA delta configuration from configuration in IFC delta dictionary form.

    @param ifc_delta_cfg_dict: dict
    for serviceModiy, it is the form
        configuration = {
          (device) : {
              # Device Shared configuration
             (folders): {
                (folders): {
                   (params):
                    ...
                },
                (params):
                ...
             }
             (functionGroup Config): {
                 (connectors):

                 (folders): {
                    (folders): {
                       (params):
                        ...
                    },
                    (params):
                    ...
                 }

                 (function) : {
                     (folders): {
                        (folders): {
                           (params):
                            ...
                        },
                        (params):
                        ...
                     }
                 }
             }
          }

        for deviceModify, it is of the form
        configuration = {
                 (folders): {
                    (folders): {
                       (params):
                        ...
                    },
                    (params):
                    ...
             }
          }


        Configuration Dictionary Format:

            (Type, Key, Instance) : {'state': State, 'device': Device, 'connector': Connector, 'value': Value}
            #
            # Type of attribute
            #
            Type = Insieme.Fwk.Enum(
                DEV=0,
                GRP=1,
                CONN=2,
                FUNC=3,
                FOLDER=4,
                PARAM=5
            )

            #
            # State of the attribute
            #
            State = Insieme.Fwk.Enum(
                NOCHANGE=0,
                CREATE=1,
                MODIFY=2,
                DESTROY=3

            Key: the key of the configuration element given in the device specification file

            Instance: the instance identifier of a configuration object, such the name of an ACL

            Connector: the connector name

            Device: the device name, such as the case in a HA configuration situation.

    @return list of CLI's
    '''
    asa = DeviceModel()
    'ifc_cfg is a copy of ifc_delta_cfg_dict suited for us.'
    ifc_cfg = massage_param_dict(asa, ifc_delta_cfg_dict)

    '''Since the input dictionary is in arbitrary order, we use two-pass approach to make sure resulting
    CLI list is in the right order given in the device model.
    '''

    #1st pass
    asa.populate_model(ifc_cfg.keys()[0], ifc_cfg.values()[0])

    #2nd pass
    cli_list = []
    no_cli_stack = []
    asa.ifc2asa(no_cli_stack, cli_list)

    #gather result from positive and negative forms for the CLIs
    result = no_cli_stack
    result.reverse() #last in first out for the 'no' CLIs
    result.extend(cli_list)
    format_cli(result)

    return result

def generate_ifc_delta_cfg(ifc_cfg_dict, asa_clis):
    '''Compare ifc configuration with asa configuration , and produce
    ifc configuration delta.

    @param asa_clis: list
        input/out list of CLI's read from ASA device
    @param ifc_cfg_dict: dict
        the configuration of ASA in IFC dictionary format. It will be modified
        after the comparison.
    @return dict
        a copy of ifc_cfg_dct but with the state of each entry set to indicate
        if a modification operation or create operation is required.
    '''
    asa = DeviceModel()

    def create_missing_ifc_delta(ifc_cfg):
        'Transformer to fill in the missing folders. This is important for configuration deletion'
        asa.populate_model(ifc_cfg.keys()[0], ifc_cfg.values()[0])
        'The following call will modify ifc_cfg'
        asa.create_missing_ifc_delta_cfg()
        return ifc_cfg

    def set_cfg_state_2_CREATE(ifc_cfg):
        'Transformer to set the State of each entry to CREATE, the default state of all entries'
        set_cfg_state(ifc_cfg, State.CREATE)
        return ifc_cfg

    'ifc_cfg is a copy of ifc_cfg_dict suited for us.'
    ifc_cfg = massage_param_dict(asa, ifc_cfg_dict,
                                 transformers=[set_cfg_state_2_CREATE,
                                               create_missing_ifc_delta])

    '''Since the input dictionary is in arbitrary order, we use two-pass approach to make sure resulting
    CLI list is in the right order given in the device model.
    '''
    for cli in asa_clis:
        translator = asa.get_translator(cli)
        if translator:
            translator.diff_ifc_asa(cli)
    return ifc_cfg

def generate_asa_delta_cfg(ifc_cfg, asa_cfg):
    '''Generate CLIs that represent the delta between given IFC configuration and ASA configuration
    @param ifc_cfg: dict
    @param asa_cfg: list of CLIs
    @return: list of CLIs
    '''
    ifc_delta_cfg = generate_ifc_delta_cfg(ifc_cfg, asa_cfg)
    return ifc2asa(ifc_delta_cfg)


class DeviceModel(DMObject):
    '''
    This is the complete representation of the ASA configuration in IFC model. The structure should be the same as
    device_specification.xml. Namely, at the top level, we have the
        - MFunc: the function configuration. In our case, it is "firewall"
        - MGrpCfg: the configuration shared by different functions.
          Not sure what it mean for ASA, since we have only one function now, that is "firewall".
        - MDevCfg: the configuration shared by all groups.
    The order to register the components is important, like in ASDM: that is the order to translate configuration
    from IFC format to ASA format.

    NOTE:
    The configuration structure of the device_specification.xml is based on "Insieme Service Management Integration"
    version 0.2. It is not quite in the final state yet, and is very likely to change.
    '''

    def __init__(self):
        '''
        Constructor
        '''
        DMObject.__init__(self, ifc_key = DeviceModel.__name__)

        'All the stuff defined in vnsMDevCfg section of device_specification.xml'
        self.register_child(DMList('VIF', Vif))
        self.register_child(DMList('VLAN', Vlan))
        self.register_child(DMList('ENCAPASS', EncapAss))
        self.register_child(DMList('InterfaceConfig', IPAddress))
        self.register_child(HostObjects())
        self.register_child(SubnetObjects())
        self.register_child(RangeObjects())
        self.register_child(FQDNObjects())
        self.register_child(ICMP4Objects())
        self.register_child(ICMP6Objects())
        self.register_child(ProtocolObjects())
        self.register_child(TCPObjects())
        self.register_child(UDPObjects())
        self.register_child(DMList('AccessList', AccessList))
        self.register_child(LoggingConfig())
        self.register_child(FailoverConfig())
        self.register_child(AccessGroupGlobal())
        self.register_child(ApplicationInspection())
        self.register_child(Timeouts())
        self.register_child(BasicThreatDetection())
        self.register_child(AdvancedThreatDetection())
        self.register_child(ScanningThreatDetection())
        self.register_child(IPAudit())

        'Child for vsnGrpCfg element'
        self.register_child(SharedConfig())

class SharedConfig(DMObject):
    '''
    This is the group configuration of ASA, assuming the name of "MGrpCfg" element in
    the device_specifcation is "GroupConfig".
    Add group configuration objects by call self.register_child(dmobj) in
    the constructor as it is done in DeviceModel.__init(self)__.
    '''

    def __init__(self):
        '''
        Constructor
        @attention:
            Insieme simulator v.04 hard code name of ""MGrpCfg" element to "Grp",
            so we just name it according for now.
        @todo:
            check later Insieme simulator to see if it uses the name of "MGrpCfg"
            element from our device specification file.
        '''
        DMObject.__init__(self, SharedConfig.__name__)
        self.register_child(Firewall())

class Firewall(DMObject):
    '''
    This is the function configuration of ASA, assuming the name of "MFunc" element in the device_specifcation is "Firewall".
    Add firewall related configuration objects by call self.register_child(dmobj) in
    the constructor as it is done in DeviceModel.__init(self)__.
    '''
    def __init__(self):
        '''
        Constructor
        '''
        DMObject.__init__(self, Firewall.__name__)
        self.register_child(ExIntfConfigRelFolder())
        self.register_child(InIntfConfigRelFolder())
        self.register_child(Connectors('CONN', Connector))
        self.register_child(DMList('AccessGroup', AccessGroup))
        self.register_child(IntStaticRoute())
        self.register_child(ExtStaticRoute())

    def get_connector(self, connector_name):
        for conn in self.get_child('CONN').children.itervalues():
            if 'conn_type' in conn.__dict__ and conn.conn_type == connector_name:
                return conn
        return None

###============= just for testing ====
if __name__ == '__main__':

    #test simple functional configuration with Timeouts
    config = {(Type.DEV, '', 4192): {
                 'transaction': 10000,
                 'state': 1,
                 'value': {
                            (Type.ENCAPASS, '', 'Firewall_outside_4113'): {
                                 'vif': "",
                                 'transaction': 10000,
                                 'encap': "",
                                 'state': 1},
                            (Type.VIF, '', 'Firewall_outside'): {
                                 'transaction': 10000,
                                 'cifs': {'FW1':'Port-channel1'},
                                 'state': 1},
                            (Type.ENCAP, '', '15364'): {
                                 'transaction': 10000,
                                 'type': 0,
                                 'state': 1,
                                 'tag': 0},
                            (Type.ENCAPASS, '', 'Firewall_outside_15364'): {
                                 'vif': "",
                                 'transaction': 10000,
                                 'encap': "",
                                 'state': 1},
                            (Type.ENCAP, '', '4113'): {
                                 'transaction': 10000,
                                 'type': 0,
                                 'state': 1,
                                 'tag': 0},
                           (Type.GRP, '', 4256): {
                                'transaction': 10000,
                                'value': {
                                    (Type.FUNC, 'Firewall', 'Node2'): {
                                        'transaction': 10000,
                                        'value': {
                                            (Type.CONN, 'external', 'C5'): {
                                               'transaction': 10000,
                                               'value': {},
                                               'state': 1},
                                            (Type.CONN, 'internal', 'C4'): {
                                              'transaction': 10000,
                                              'value': {},
                                              'state': 1}},
                                        'state': 1}},

                                  'state': 1}}}}
    asa = DeviceModel()

    def create_missing_ifc_delta(ifc_cfg):
        'Transformer to fill in the missing folders'
        asa.populate_model(ifc_cfg.keys()[0], ifc_cfg.values()[0])
        asa.create_missing_ifc_delta_cfg()
        return ifc_cfg

    def set_cfg_state_2_DESTROY(ifc_cfg):
        'Transformer to set the State of each entry to DETROY'
        set_cfg_state(ifc_cfg, State.DESTROY)
        return ifc_cfg

    ifc_cfg = massage_param_dict(asa, config,
                                 transformers=[set_cfg_state_2_DESTROY,
                                               create_missing_ifc_delta])

    from utils.util import pretty_dict
    print pretty_dict(ifc_cfg)

#    print("Test functional configuration  with Timeouts: %s"  % [str(x) for x in clis])

