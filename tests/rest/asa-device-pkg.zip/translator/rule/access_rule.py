'''
Created on Jul 15, 2013

@author: jeffryp

Copyright (c) 2013 by Cisco Systems, Inc.
All rights reserved.

Classes used for access rules.
'''

import translator
from translator.state_type import State
from translator.base.dmlist import DMList
from translator.base.dmobject import DMObject
from translator.base.simpletype import SimpleType
import utils.env as env
import utils.util as util


class AccessGroup(SimpleType):
    'A single access group'

    def __init__(self, instance):
        SimpleType.__init__(
            self,
            ifc_key=instance,
            asa_gen_template='access-group %(access_list_name)s %(direction)s interface %(interface_name)s',
            is_removable=True)

    def get_cli(self):
        values = util.normalize_param_dict(self.delta_ifc_cfg_value['value'])
        connector_name = values.get('connector', '')
        firewall = self.get_ancestor_by_class(translator.devicemodel.Firewall)
        connector = firewall.get_connector(connector_name)
        if not connector:
            env.debug('AccessGroup: Unable to get connector "' + connector_name + '"')
            return ''

        values['interface_name'] = connector.get_nameif()
        return self.asa_gen_template % values

class AccessGroupGlobal(SimpleType):
    'The single global access group'

    def __init__(self):
        SimpleType.__init__(
            self,
            ifc_key=AccessGroupGlobal.__name__,
            asa_gen_template='access-group %(access_list_name)s global',
            is_removable=True)

class AccessControlEntry(DMObject):
    'A single access control entry (ACE)'

    def __init__(self, instance):
        DMObject.__init__(self, ifc_key=instance)

    def equals_no_order(self, ace):
        'Return True if two ACEs have equal attributes other than order'
        for key, value in self.values.iteritems():
            if key != 'order' and value != ace.values.get(key):
                return False
        return True

    def get_cli(self, line_no=None):
        cli = []
        cli.append('access-list ' + self.parent.ifc_key)
        if line_no:
            cli.append(' line ' + str(line_no))
        cli.append(' extended %(action)s %(protocol)s any any' % self.values)
        if 'destination_port' in self.values:
            AccessControlEntry.append_port(
                cli, self.values['destination_port'])
        return ''.join(cli)

    def generate_command(self, asa_cfg_list, line_no=None):
        self.generate_cli(
            asa_cfg_list,
            self.get_cli(line_no),
            model_key=self.delta_ifc_key)

    def generate_delete(self, asa_cfg_list):
        self.generate_cli(
            asa_cfg_list,
            'no ' + self.get_cli(),
            model_key=self.delta_ifc_key)

    def populate_model(self, delta_ifc_key, delta_ifc_cfg_value):
        super(AccessControlEntry, self).populate_model(
            delta_ifc_key, delta_ifc_cfg_value)
        self.values = util.normalize_param_dict(
            self.delta_ifc_cfg_value['value'])

    def __str__(self):
        return self.get_cli()

    @staticmethod
    def append_port(cli, service):
        cli.append(' %(operator)s %(low_port)s' % service)
        if service['operator'] == 'range':
            cli.append(' %(high_port)s' % service)

class AccessList(DMList):
    'A single access list that contains access control entries (ACE)'

    def __init__(self, instance):
        DMList.__init__(self, instance, AccessControlEntry)

    def ifc2asa(self, no_asa_cfg_stack, asa_cfg_list):
        state = self.delta_ifc_cfg_value['state']
        if state in (State.CREATE, State.MODIFY):
            if state == State.CREATE:
                # Sort the ACEs into order
                access_control_entries = list(self.children.itervalues())
                access_control_entries.sort(
                    key=lambda ace: int(ace.values['order']))
                for ace in access_control_entries:
                    ace.generate_command(asa_cfg_list)
            else:
                self.generate_delta(no_asa_cfg_stack, asa_cfg_list)
        elif state == State.DESTROY:
            self.generate_cli(
                no_asa_cfg_stack,
                'clear config access-list ' + self.ifc_key,
                model_key=self.delta_ifc_key)

    def generate_delta(self, no_asa_cfg_stack, asa_cfg_list):
        'Optimize the generated CLI by looking for ACEs that have moved'

        # Split into old and new config
        old_config = []
        new_config = []
        for ace in self.children.itervalues():
            state = ace.delta_ifc_cfg_value['state']
            if state == State.NOCHANGE:
                old_config.append(ace)
                new_config.append(ace)
            elif state == State.CREATE:
                new_config.append(ace)
            elif state == State.DESTROY:
                old_config.append(ace)

        # Sort the old and new config
        old_config.sort(key=lambda ace: int(ace.values['order']))
        new_config.sort(key=lambda ace: int(ace.values['order']))

        # List of new positions corresponding to the old positions.  e.g. if the
        # first ACE in the old config is now in position 4 of the new config,
        # then new_positions[0] == 4
        new_positions = []

        # The element at old_positions[i] is equal to the element at
        # new_positions[i].  This is used to keep track of what has changed
        # during the traversal of the old config for optimizing the CLI when
        # traversing the new config 
        old_positions = []

        # List of old positions that have been deleted
        delete_old_positions = []

        for i, ace in enumerate(old_config):
            pos = AccessList.equal_ace_position(new_config, ace)
            if pos < 0:
                delete_old_positions.append(i)
            else:
                new_positions.append(pos)
                old_positions.append(i)

        # Handle the case where all the ACEs in an access list have been either
        # deleted or moved.  Normally, all the ACEs would first be deleted and
        # then the changed ones would be added back.  However, if the access
        # list is in use, then the ASA will delete all polices using the access
        # list when the last ACE is deleted.  To get around this, the first
        # changed ACE is added before any ACEs are deleted. 
        is_rebuilt = (len(delete_old_positions) == len(old_config) and
                      len(new_config) > 0)

        # Delete what was moved and what was deleted
        what_moved = AccessList.what_moved(new_positions)
        for i in what_moved:
            delete_old_positions.append(old_positions[new_positions.index(i)])
        for i in delete_old_positions:
            old_config[i].generate_delete(no_asa_cfg_stack)

        # If the access list is rebuilt, add the first changed ACE to the end
        # of the 'no' CLI list.  After the 'no' list is reversed, the first
        # changed ACE will be before any ACEs to be removed.
        if is_rebuilt:
            new_config[0].generate_command(no_asa_cfg_stack, line_no=1)

        # Add what was added or moved
        start = 1 if is_rebuilt else 0
        for i, ace in enumerate(new_config[start:], start):
            if i not in new_positions or i in what_moved:
                ace.generate_command(asa_cfg_list, line_no=i + 1)

    def populate_model(self, delta_ifc_key, delta_ifc_cfg_value):
        self.delta_ifc_key = delta_ifc_key
        self.delta_ifc_cfg_value = delta_ifc_cfg_value
        for key, value in delta_ifc_cfg_value['value'].iteritems():
            super(AccessList, self).populate_model(key, value)

    @staticmethod
    def equal_ace_position(new_config, old_ace):
        'Find position of the ACE in the new config'
        for i, new_ace in enumerate(new_config):
            if new_ace.equals_no_order(old_ace):
                return i
        return -1

    @staticmethod
    def longest_increasing_subsequence(x):
        '''
        Finds the longest increasing subsequence of the specified sequence.

        The subsequence is in sorted order (lowest to highest) and is as long as
        possible.  The subsequence is not necessarily contiguous.

        As an example, for the following sequence:
            1,2,0,3,4,5,6
        the longest increasing subsequence is:
            1,2,3,4,5,6
        '''

        if not x:
            return []

        best = [0]
        pred = [0] * len(x)
        for i in xrange(1, len(x)):
            if cmp(x[best[-1]], x[i]) < 0:
                pred[i] = best[-1]
                best.append(i)
                continue

            low = 0
            high = len(best) - 1
            while low < high:
                mid = (low + high) / 2
                if cmp(x[best[mid]], x[i]) < 0:
                    low = mid + 1
                else:
                    high = mid

            if cmp(x[i], x[best[low]]) < 0:
                if low > 0:
                    pred[i] = best[low -1]
                best[low] = i

        result = []
        j = best[-1]
        for i in xrange(len(best)):
            result.insert(0, x[j])
            j = pred[j]
        return result

    @staticmethod
    def what_moved(positions):
        if len(positions) <= 1:
            return []

        sequence = AccessList.longest_increasing_subsequence(positions)
        moved_positions = []
        for i in positions:
            if i not in sequence:
                moved_positions.append(i)
        return moved_positions
