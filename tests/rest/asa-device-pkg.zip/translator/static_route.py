#
# Copyright (c) 2013 by Cisco Systems, Inc.
#
'''
Created on Jun 28, 2013

@author: feliu

This is the static route class.

'''

import translator
from translator.state_type import Type, State
from translator.base.dmobject import DMObject
from translator.base.dmlist import DMList
from translator.base.simpletype import SimpleType
import utils.util as util


class IntStaticRoute(DMObject):
    def __init__(self):
        DMObject.__init__(self, 'IntStaticRoute')
        self.register_child(DMList('route', Route, 'route '))
        self.register_child(DMList('ipv6route', IPv6Route, 'ipv6 route'))

class ExtStaticRoute(DMObject):
    def __init__(self):
        DMObject.__init__(self, 'ExtStaticRoute')
        self.register_child(DMList('route', Route, 'route '))
        self.register_child(DMList('ipv6route', IPv6Route, 'ipv6 route'))

class Route(SimpleType):
    '''
    This class represents the holder of all IPv4 static routes.
    '''

    def __init__(self, name):
        SimpleType.__init__(self, name,
                            asa_gen_template = 'route %(interface)s %(network)s %(netmask)s %(gateway)s %(metric)s',
                            response_parser = static_route_response_parser,
                            defaults={'metric': '1'})

    def get_cli(self):
        value = self.get_value_with_connector()
        return ' '.join(str(self.asa_gen_template % value).split())

    def get_value_with_connector(self):
        assert self.has_ifc_delta_cfg()
        value = util.normalize_param_dict(self.delta_ifc_cfg_value['value'])
        nameif = None
        connector_name = 'internal' if self.parent.parent.ifc_key == 'IntStaticRoute' else 'external'
        firewall = self.get_ancestor_by_class(translator.devicemodel.Firewall)
        connector = firewall.get_connector(connector_name)
        if connector:
            nameif = connector.get_nameif()

        'Take care of defaults'
        if self.defaults:
            #filling the default values for missing parameters
            if isinstance(value, dict):
                for name in self.defaults:
                    value[name] = value.get(name, self.defaults[name])
        if nameif:
            value['interface'] = nameif

        return value

    def ifc2asa(self, no_asa_cfg_stack, asa_cfg_list):
        value = self.get_value_with_connector()
        'Prevent the deletion of route on management interface or IFC will not able to connect to the ASA'
        self.is_removable = value.get('interface') != 'management'
        return SimpleType.ifc2asa(self, no_asa_cfg_stack, asa_cfg_list)

    def create_asa_key(self):
        '''Create the the asa key identifies this object, everything except 'metric' make up the key
        @return str
        '''
        value = self.get_value_with_connector()
        return 'route %(interface)s %(network)s %(netmask)s %(gateway)s' % value

    def parse_multi_parameter_cli(self, cli):
        '''Override the default implementation in case the CLI does not match asa_gen_template due to optional
        parameter
        '''
        result = SimpleType.parse_multi_parameter_cli(self, cli)
        if not result:
            'metric parameter missing in cli, use the default value and try again'
            result = SimpleType.parse_multi_parameter_cli(self, cli + ' ' + self.defaults['metric'])
        return result


class IPv6Route(Route):
    '''
    This class represents the holder of all IPv6 static routes.
    '''

    def __init__(self, name):
        '''@todo: use Route.__init__ instead of SimpleType.__init__
           Route.__init__(self, name, defaults=None, asa_gen_template = 'ipv6 route %(interface)s %(prefix)s %(gateway)s')
        '''
        SimpleType.__init__(self, name,
                            asa_gen_template = 'ipv6 route %(interface)s %(prefix)s %(gateway)s %(hop_count)s %(tunneled)s',
                            defaults = {'hop_count': '', 'tunneled': ''},
                            response_parser = static_route_response_parser)

    def get_cli(self):
        value = self.get_value_with_connector()
        return ' '.join(str(self.asa_gen_template % value).split())

    def get_value_with_connector(self):
        assert self.has_ifc_delta_cfg()
        value = util.normalize_param_dict(self.delta_ifc_cfg_value['value'])
        nameif = None
        connector_name = 'internal' if self.parent.parent.ifc_key == 'IntStaticRoute' else 'external'
        firewall = self.get_ancestor_by_class(translator.devicemodel.Firewall)
        connector = firewall.get_connector(connector_name)
        if connector:
            nameif = connector.get_nameif()

        'Take care of defaults'
        if self.defaults:
            #filling the default values for missing parameters
            if isinstance(value, dict):
                for name in self.defaults:
                    value[name] = value.get(name, self.defaults[name])
        if nameif:
            value['interface'] = nameif
        return value

    def create_asa_key(self):
        '''Create the the asa key identifies this object, everything except 'metric' make up the key
        @return str
        '''
        value = self.get_value_with_connector()
        'Prevent the deletion of route on management interface or IFC will not able to connect to the ASA'
        self.is_removable = value.get('interface') != 'management'
        return 'ipv6 route %(interface)s %(prefix)s %(gateway)s' % value

    def parse_multi_parameter_cli(self, cli):
        '''Override the default implementation in case the CLI does not match asa_gen_template due to optional
        parameter
        '''
        'Take care of the mandatory parameters'
        result = SimpleType.parse_multi_parameter_cli(self, cli, alternate_asa_gen_template = 'ipv6 route %(interface)s %(prefix)s %(gateway)s')

        'Take care of the optional parameters'
        for name, value  in self.defaults.iteritems():
            result[(Type.PARAM, name, '')] = {'state': State.NOCHANGE, 'value': value}
        tokens = cli.split()
        if len(tokens) == 5:
            return result #no optional parameter

        option = tokens[5]
        if option == 'tunneled':
            result[Type.PARAM, 'tunneled', '']['value'] = option
        elif option:
            result[Type.PARAM, 'hop_count', '']['value'] = option

        return result


def static_route_response_parser(response):
    '''
    Ignores expected INFO, WARNING, and error in the response, otherwise returns original.
    '''

    if response:
        msgs_to_ignore = ('INFO:',
                          'WARNING:',
                          'No matching route to delete')
        found_msg_to_ignore = False
        for msg in msgs_to_ignore:
            if msg in response:
                found_msg_to_ignore = True
    return None if response and found_msg_to_ignore else response
