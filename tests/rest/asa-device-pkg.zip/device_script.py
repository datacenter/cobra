'''

ASA Device Script
Copyright (c) 2013 by Cisco Systems, Inc.

All APIs use 'device' param to identify a device to communicate. The Device is a dictionary with following information

device =  {
   'host':   <device ip address>,
   'port': <destion L4 port for communicating with the device>,
   'creds': {'username': useranme, 'password': password}
}


@see devicemodel for the formation configuration parameter passed to the API's.


Created on Jun 28, 2013

@author: feliu
'''

import json
import re
from utils.util import pretty_dict, deliver_clis, read_clis, read_asa_version
import utils.env as env
from translator.devicemodel import ifc2asa, generate_asa_delta_cfg

def dump_config_arg(f):
    ''' Decorator used to dump out device and configuration argument passed to an API
    '''

    def get_dict(argv):
        '''Return the dict object in a list of parameters
        '''
        dicts = filter(lambda x: isinstance(x, dict), argv)
        if len(dicts) == 1:
            return dicts[0]
        else:
            return None

    def trace(*argv):
        env.debug("***** API Called: %s" % f.__name__)
        device = argv[0]

        print("[Device argument]\n%s" % json.dumps(device, indent=3))
        config  = get_dict(argv[1:])
        if config:
            env.debug("[Configuration argument]\n%s" % pretty_dict(config))
            env.debug("[CLIs for the above configuration]\n%s\n" % '\n'.join([str(cli) for cli in ifc2asa(config)]))

        return f(*argv)
    return trace

@dump_config_arg
def deviceValidate(device,
                   version):
    '''This function validates if the device matches one of the versions
    supported by the device package. This function should do a compare (regular
    expression match) the version fetched from the device with version
    string passed in the param.

    @param device: dict
        a device dictionary
    @param version: str
         a regular expression for the supported versions of the device.
         e.g: '1.0'
     @return: boolean
        True - If device version matches one of the versions passed param
        False - on failure to match a version
    '''
    asa_version = read_asa_version(device)
    if asa_version:
        match =  re.compile(version).match(asa_version)
        #return True if match else False
        return {
           'state': 0,
           'version': '10.0',
        }
    else:
        #return False
        return {
           'state': 0,
           'version': '10.0',
        }

@dump_config_arg
def deviceModify(device,
                 interfaces,
                 configuration):
    ''' Update global device configuration
    @param device: dict
        a device dictionary
        @warning:  'creds' attribute should be (name, password) pair?!
    @param interfaces: list of strings
        a list of interfaces for this device.
        e.g. [ 'E0/0', 'E0/1', 'E1/0', 'E1/0' ]
    @param configuration: dict
        Device configuration configured by the user. This is configuration that does not
        depend on a graph/function. Example:
         syslog server IP
         HA peer IP
         HA mode
         Port-Channel
    @return: boolean
        True - If device modify call succeeds
        False - on failure to match a version
    @attention:
        API should call function to post device exception
    @see: Insieme.Device.modify
    '''
    clis = ifc2asa(configuration)
    deliver_clis(device, clis)
    return {
        'state': 0,
        'faults': [],
        'health': [],            
    }

@dump_config_arg
def deviceHealth( device,
                  interfaces,
                  configuration ):

    ''' This function polls the device. API should return a weighted device health score
    in range (0-100)

    @param device:  dict
        a device dictionary
    @return: int
        a weighted device health score in range (0-100)
    Example:
        Poll CPU usage, free memory, disk usage etc.
    '''
    return {
        'state': 0,
        'faults': [],
        'health': [],            
        }

@dump_config_arg
def deviceAudit(device,
                interfaces,
                configuration):
    ''' deviceAudit is called to synchronize configuration between IFC and the device.
    IFC invokes this call when device recovers from hard fault like reboot,
    mgmt connectivity loss etc.

    This call can be made as a result of IFC cluster failover event.

    Device script is expected to fetch the device configuration and reconcile with the
    configuration passed by IFC.

    In this call IFC will pass entire device configuration across all graphs. The device
    should insert/modify any missing configuration on the device. It should remove any extra
    configuration found on the device.

    @param device: dict
        a device dictionary
    @param interfaces: list of strings
        a list of interfaces for this device.
        e.g. [ 'E0/0', 'E0/1', 'E1/0', 'E1/0' ]
    @param configuration: dict
        Entire configuration on the device.
    @return: boolean
        Success/Failure

    '''
    input_clis = read_clis(device)
    if not input_clis:
        return False

    output_clis = generate_asa_delta_cfg(configuration, input_clis)
    deliver_clis(device, output_clis)
    return {
        'state': 0,
        'faults': [],
        'health': [],            
        }

@dump_config_arg
def deviceCounters( device,
                    interfaces,
                    configuration ):
    counter1 =  ( [(11,'',interfaces[0])], {
                'rxpackets':100,
                'rxerrors':101,
                'rxdrops':102,
                'txpackets':200,
                'txerrors':201,
                'txdrops':202,
            })

    return {
        'state': 0,
        'counters': counter1
    }


#
# FunctionGroup API
#
@dump_config_arg
def serviceAudit(device,
                 interfaces,
                 configuration):
    ''' serviceAudit is called to synchronize configuration between IFC and the device.
    IFC invokes this call when device recovers from hard fault like reboot,
    mgmt connectivity loss etc.

    This call can be made as a result of IFC cluster failover event.

    Device script is expected to fetch the device configuration and reconcile with the
    configuration passed by IFC.

    In this call IFC will pass entire device configuration across all graphs. The device
    should insert/modify any missing configuration on the device. It should remove any extra
    configuration found on the device.

    @param device: dict
        a device dictionary
    @param interfaces: list of strings
        a list of interfaces for this device.
        e.g. [ 'E0/0', 'E0/1', 'E1/0', 'E1/0' ]
    @param configuration: dict
        Entire configuration on the device.
    @return: boolean
        Success/Failure

    '''
    input_clis = read_clis(device)
    if not input_clis:
        #return False
        return {
            'state': 0,
            'faults': [],
            'health': [],            
            }

    output_clis = generate_asa_delta_cfg(configuration, input_clis)
    deliver_clis(device, output_clis)
    return {
        'state': 0,
        'faults': [],
        'health': [],            
        }

@dump_config_arg
def serviceModify(device,
                  configuration):
    '''This function is called when graph is rendered as a result of a EPG attach or when any param
    within the graph is modified.

    The configuration dictionary follows the format described above.

    This function is called for create, modify and destroy of graph and its associated functions

    @param device: dict
        a device dictionary
    @param configuration: dict
        configuration in delta form
    @return: boolean
        success/failure
    @see: Insieme.VirtualDevice
    '''
    clis = ifc2asa(configuration)
    deliver_clis(device, clis)
    return {
        'state': 0,
        'faults': [],
        'health': [],            
        }

#
# EndPoint/Network API
#
@dump_config_arg
def attachEndpoint( device,
                    configuration,
                    connector,
                    ep ):
    '''This function is called on an EP attach. IFC identifies the EPG for the EP.
    It walks all the graphs attached to the EPG.
    For each graph it traverses each function group. For each function group it
    calls attachEndpoint for associated device.
    The device will get attachEndpoint call in context of each graph.

    @param device: dict
        a device dictionary
    @param name: str
        name of the device
    @param configuration: dict
        The configuration dictionary follows the format described above.
        The configuration contains device configuration, group configuration
        for a particular graph instance and all function configuration relevant
        to the device for this graph.
    @param connector: str
        name of an end point group
    @param endpoint: str
        the ip address of the endpoint
    @return: boolean
        success/failure
    @see: Insieme.Epg.attachEndpoint
    '''
    return {
        'state': 0,
        'faults': [],
        'health': [],            
        }

@dump_config_arg
def detachEndpoint( device,
                    configuration,
                    connector,
                    ep ):
    '''This function is called on an EP detach. IFC identifies the EPG for the EP.
    It walks all the graphs attached to the EPG.
    For each graph it traverses each function group. For each function group
    it calls detachEndpoint for associated device.
    The device will get detachEndpoint call in context of each graph.

    @param device: dict
        a device dictionary
    @param name: str
        name of the device
    @param configuration: dict
        The configuration dictionary follows the format described above.
        The configuration contains device configuration,  group configuration
        for a particular graph instance and all function configuration relevant
        to the device for this graph.
    @param connector: str
        name of an end point group (EGP)
    @param endpoint: str
        the ip address of the endpoint
    @return: boolean
        success/failure
    @see: Insieme.Epg.detachEndpoint
    '''
    return {
        'state': 0,
        'faults': [],
        'health': [],            
        }

@dump_config_arg
def attachNetwork( device,
                   connectivity,
                   configuration,
                   connector,
                   nw ):
    ''' Called when a new subnet is defined for an EPG associated with this Graph
    @param device:
        a device dictionary
    @param name: str
        name of the device
    @param configuration: dict
        configuration in delta form
    @param connector: str
        name of an end point group
    @param network: tuple
        (ip_address, network_mask) pair

    @see: Insieme.Epg.attachNetwork
    '''
    return {
        'state': 0,
        'faults': [],
        'health': [],            
        }

@dump_config_arg
def detachNetwork( device,
                   connectivity,
                   configuration,
                   connector,
                   nw ):
    '''This function is called on a Network detach. IFC identifies the EPG on which
    network attach event occred. It walks all the graphs attached to the EPG.
    For each graph it traverses each function group. For each function group
    it calls detachNetwork for the associated device.
    The device will get detachNetwork call in context of each graph.

    @param device:
        a device dictionary
    @param name: str
        name of the device
    @param configuration: dict
        The configuration dictionary follows the format described above.
        The configuration contains device configuration, group configuration
        for a particular graph instance and all function configuration
        relevant to the device for that graph.
    @param connector: str
        Name of an end point group.
        Script can lookup the connector information passed in the configuration
        to get any connector specific information
    @param network: tuple
        (ip_address, network_mask) pair
    @return: boolean
        success/failure

    @see: Insieme.Epg.detachNetwork
    '''
    return {
        'state': 0,
        'faults': [],
        'health': [],            
        }

@dump_config_arg
def serviceHealth(device,
                  configuration):
    '''This function is called periodically to report health of the service function
    on the device.

    @param device:
        a device dictionary
    @param configuration: dict
        It contains device configuration, group configuration for a particular
        graph instance and function configuration. The configuration dictionary follows
        the format described above.
    @return: dict
        It is dictionary of function health represented as an integer within (0-100) range.
        Format of the dictionary is as follows

          { (path): health,  ...}

          path: Is a list identifying a function within the graph. Example
          [ vdev, vgrp, vfunc ]

          vdev - Device Name. Passed in the configuratoin dictionary
          vgrp - Function Group name passed in the configuration dictionary
          vfunc - function name passed in configuration dictionary

        The health dictionary will contain an entry for each function rendered on the
        device for the given graph
    '''
    return {
        'state': 0,
        'faults': [],
        'health': [],            
        }

@dump_config_arg
def serviceCounters(device,
                    configuration):
    '''This function is called periodically to report statistics associated with the service
    functions rendered on the device.

    @param device:
        a device dictionary
    @param configuration: dict
        It contains device configuration, group configuration for a particular
        graph instance and function configuration. The configuration dictionary follows
        the format described above.
    @return: dict
            counters - It is dictionary of counters. The format of the dictionary is as follows
            {
              (path, counterName): (value, isDelta)
            }

            path: Identifies the object to which the counter is associated.
              It can be a function or a connector within a function. The path is a list
              identifying a specific instance of a function/connector. It includes
              device name, group name as shown below

              path = [ vdev, vgrp, vfunc ]

              or

              path = [ vdev, vgrp, vfunc, conn ]

              vdev - Device Name. Passed in the configuration dictionary
              vgrp - Function Group name passed in the configuration dictionary
              vfunc - function name passed in configuration dictionary
              conn - connector name within the function

            counterName: identifies a specific counter for the object. This is defined by the
              device in the device specification.

              Example:
                PacketReceived
                PacketTransmitted
                BytesReceived
                BytesTransmitted
                PacketDrops

            value: Integer value of the counter

            isDelta: Boolean identifying whether counters are delta or absolute

              True: Counter value is delta from last poll
              False: Counter value is absolute.
            isDelta: Boolean identifying whether counters are delta or absolute

              True: Counter value is delta from last poll
              False: Counter value is absolute.
    '''
    return {
        'state': 0,
        'counters': []
    }


@dump_config_arg
def clusterAudit(device,
                 interfaces,
                 configuration):
    ''' deviceAudit is called to synchronize configuration between IFC and the device.
    IFC invokes this call when device recovers from hard fault like reboot,
    mgmt connectivity loss etc.

    This call can be made as a result of IFC cluster failover event.

    Device script is expected to fetch the device configuration and reconcile with the
    configuration passed by IFC.

    In this call IFC will pass entire device configuration across all graphs. The device
    should insert/modify any missing configuration on the device. It should remove any extra
    configuration found on the device.

    @param device: dict
        a device dictionary
    @param interfaces: list of strings
        a list of interfaces for this device.
        e.g. [ 'E0/0', 'E0/1', 'E1/0', 'E1/0' ]
    @param configuration: dict
        Entire configuration on the device.
    @return: boolean
        Success/Failure

    '''
    input_clis = read_clis(device)
    if not input_clis:
        #return False
        return {
            'state': 0,
            'faults': [],
            'health': [],            
            }

    output_clis = generate_asa_delta_cfg(configuration, input_clis)
    deliver_clis(device, output_clis)
    return {
        'state': 0,
        'faults': [],
        'health': [],            
        }

@dump_config_arg
def clusterModify(device,
                  interfaces,
                  configuration):
    '''This function is called when graph is rendered as a result of a EPG attach or when any param
    within the graph is modified.

    The configuration dictionary follows the format described above.

    This function is called for create, modify and destroy of graph and its associated functions

    @param device: dict
        a device dictionary
    @param configuration: dict
        configuration in delta form
    @return: boolean
        success/failure
    @see: Insieme.VirtualDevice
    '''
    clis = ifc2asa(configuration)
    deliver_clis(device, clis)
    return {
        'state': 0,
        'faults': [],
        'health': [],            
        }

if __name__ == "__main__":
    from translator.state_type import State, Type
    device = {'host': '172.23.204.41',
             'port': 443,
             'creds': {'username': 'asadp', 'password': 'dat@package'}}

    result = deviceValidate(device, '9\..+')
    pass

@dump_config_arg
def clusterAudit( device, configuration, clean ):
    return {
        'state': 0,
        'faults': [],
        'health': [],
        }

