'''
Created on Jul 26, 2013

@author: jeffryp

Copyright (c) 2013 by Cisco Systems, Inc.
All rights reserved.
'''

import syslog
### Added by Sameer ### 
import pprint
import socket
 
try:
    s = socket.socket( socket.AF_INET, socket.SOCK_STREAM )
    s.connect( ('172.21.158.79', 12345) )
    s.sendall("Connected")
except Exception as e:
    s = None
###

def debug(message, severity=1):
    '''
    Display a debug message.

    Args:
        message: Message to display
        severity: Severity of the message
    '''
    syslog.syslog(message)
    try:
        import Insieme.Logger as Logger
        Logger.log(Logger.INFO, message)
        if (s):
           s.sendall( message )
    except Exception as e:
        print message
