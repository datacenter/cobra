'''
Created on Jul 25, 2013

@author: jeffryp

Copyright (c) 2013 by Cisco Systems, Inc.
All rights reserved.

Common utility functions
'''

from collections import OrderedDict
import json
import re
import copy

from asaio.dispatch import HttpDispatch
from translator.state_type import State, Type
from translator.structured_cli import convert_to_structured_commands
import utils.env as env

def key_as_string(obj):
    ''' This function makes the key into string in a dictionary.
    '''

    if isinstance(obj, dict):
        result = OrderedDict()
        for key, value in obj.iteritems():
            if isinstance(value, dict):
                result[repr(key)] = key_as_string(value)
            else:
                result[repr(key)] = value
        return result
    else:
        return obj

def pretty_dict(obj, indent=3):
    ''' This function prints a dictionary in a nicer indented form.
    '''
    return json.dumps(key_as_string(obj), indent=indent)

def normalize_param_dict(param_dict):
    '''
    Normalize a param dictionary by extracting the 'key' and 'value' into a new
    dictionary, recursively.

    @param param_dict: scalar value or param dictionary
        if it's a param dictionary, then each entry is of the format:
            (type, key, instance): {'state': state,
                                    'device': device,
                                    'connector': connector,
                                    'value':  scalar value or param dictionary}
    @return: scalar value or param dictionary
        if param_dict is a param dictionary, then return the a new dictionary
            with just the 'key' and 'value'.
        otherwise param_dict is returned
    '''

    if not isinstance(param_dict, dict):
        return param_dict

    result = {}
    for (kind, key, instance), cfg_value in param_dict.iteritems():
        'Will deprecate the check for target in the future, it should be handled at the program initialized'
        if 'target' in cfg_value:
            value = cfg_value['target']
        elif 'value' in cfg_value:
            value = cfg_value['value']
        if isinstance(value, dict):
            value = normalize_param_dict(value)
        result[key] = value
    return result


def normalize_state_param_dict(param_dict):
    '''
    Normalize a param dictionary by extracting the 'key' and 'value' into a new
    dictionary, recursively.

    @param param_dict: scalar value or param dictionary
        if it's a param dictionary, then each entry is of the format:
            (type, key, instance): {'state': state,
                                    'device': device,
                                    'connector': connector,
                                    'value':  scalar value or param dictionary}
    @return: scalar value or param dictionary
        if param_dict is a param dictionary, then return the a new dictionary
            with just the 'key' and 'value'.
        otherwise param_dict is returned
    '''

    if not isinstance(param_dict, dict):
        return param_dict

    result = {}
    for (kind, key, instance), cfg_value in param_dict.iteritems():
        'Will deprecate the check for target in the future, it should be handled at the program initialized'
        if 'target' in cfg_value:
            value = cfg_value['target']
        elif 'value' in cfg_value:
            value = cfg_value['value']
        if isinstance(value, dict):
            value = normalize_state_param_dict(value)
        result[key] = value
        result[key + '_state'] = cfg_value['state']
    return result

def ifcize_param_dict(param_dict):
    '''Reverse the operation of util.normalize_param_dict
    @param param_dict: dict
        A configuration diction in the normal format, e.g:
         {'Hostname': 'my-asa'}
    @return dict in the IFC format,
        For the above example, the return value is:
         {(Type.PARAM, 'Hostname', ''), {'state': State.NOCHANGE, 'value': 'my-asa'}}
    @todo: move it into util. But encountered cyclic-dependency problem.

    '''
    if not isinstance(param_dict, dict):
        return param_dict

    result = {}
    for key, value in param_dict.iteritems():
        kind = Type.FOLDER if isinstance(value, dict) else Type.PARAM
        if isinstance(value, dict):
            value = ifcize_param_dict(value)
        result[(kind, key, '')] = {'state': State.NOCHANGE, 'value': value}
    return result


def filter_out_sacred_commands(output_clis):
    '''Remove commands that may cause disruption of communication between IFC and the ASA device.
    @param output_clis: list of CLIInteraction's
    @return output_clis
    '''
    mgmt_intf = 'management'
    sacred_commands  = ['^no route ' + mgmt_intf,
                        '^no http enable',
                        '^no http .+ ' + mgmt_intf]

    for sacred in sacred_commands:
        cmds = filter(lambda text: re.compile(sacred).match(str(text).strip()), output_clis)
        for cmd in cmds:
            output_clis.remove(cmd)
    return output_clis

def deliver_clis(device, clis, transformers=[filter_out_sacred_commands]):
    '''Deliver a list of CLI's to an ASA device
    @param device: dict
        a device dictionary
    @param clis: list of CLIIneraction's
    @param transformers: list of function that takes one argument and return an object
        the purpose of a transformer is to transform ASA configuration to a desired format
        before actually sending them down to the ASA device.
        The order of the application of the transformer is the reverse given in the parameter,
        i.e. if the transformers is [a, b], the result will be a(b(config)).
        a list of CLI objects.
    '''
    if not deliver_clis.enabled:
        env.debug("[CLIs to be delivered]\n%s\n" % '\n'.join([str(cli) for cli in clis]))
        return True
    if not clis:
        return True;
    try:
        if transformers:
            for transformer in reversed(transformers):
                clis = transformer(clis)
        dispatcher = HttpDispatch(device)
        messenger = dispatcher.make_command_messenger(clis)
        results = messenger.get_results()
        errs = filter(lambda x: x != None and x.err_msg != None and len(x.err_msg.strip()) > 0, results)
        if len(errs) > 0:
            return False;
        else:
            return True
    except Exception as e:
        env.debug("Fails to deliver commands: %s" % e)
        return False


''' One can turn deliver_clis.enabled attribute on/off during testing.
'''
deliver_clis.enabled = True


def read_clis(device, transformers=[convert_to_structured_commands, lambda x: x.split('\n')]):
    '''Read running-configuration from ASA device
    @param device: dict
        a device dictionary
    @param transformers: list of function that takes one argument and return an object
        the purpose of a transformer is to transform ASA configuration to a desired format.
        The order of the application of the transformer is the reverse given in the parameter,
        i.e. if the transformers is [a, b], the result will be a(b(config)).
    @return: list of CLI's
    '''
    try:
        dispatcher = HttpDispatch(device)
        messenger = dispatcher.make_read_config_messenger()
        result = messenger.read()
        if result and transformers:
            for transformer in reversed(transformers):
                result = transformer(result)
        return result
    except Exception as e:
        env.debug("Fails to read commands: %s" % e)
        return None

def read_asa_version(device):
    '''Read the version information from the given device
    @param device: dict
        a device dictionary
    @return version string, such as '9.0(3)'; or None if cannot connect to the device
    '''
    try:
        version_line = 'Cisco Adaptive Security Appliance Software Version'
        pattern = r'^'+ version_line + ' (\S+)'
        dispatcher = HttpDispatch(device)
        messenger = dispatcher.make_shows_messenger(['show version | grep ' + version_line])
        result =  messenger.read()
        for line in result.split('\n'):
            m = re.match(pattern, line)
            if m:
                return m.group(1)
    except Exception as e:
        env.debug("Fails to read ASA version: %s" % e)

def set_cfg_state(ifc_cfg_dict, state):
    '''Set the state of each entry in the a given IFC configuration
     to a given state.
    @param ifc_cfg_dict: dict
        IFC configuration dictionary
    @param state: State
    '''

    if 'state' in  ifc_cfg_dict:
        ifc_cfg_dict['state'] = state

    for value in ifc_cfg_dict.values():
        if not isinstance(value, dict):
            continue
        if not 'state' in  value:
            set_cfg_state(value, state)
            continue
        value['state'] = state

        if 'cifs' in value:
            key_of_value = 'cifs'
        elif 'target' in value:
            key_of_value = 'target'
        else:
            key_of_value = 'value'
            
        ifc_cfg_dict = value.get(key_of_value)
        if isinstance(ifc_cfg_dict, dict):
            set_cfg_state(ifc_cfg_dict, state)

def fill_key_strings(param_dict):
    '''The configuration parameter passed to us from IFC runtime have key value missing for certain entries.
    These entries are for the following types:
        - Type.DEV
        - Type.GRP
        - Type.CONN
        - TYPE.ENCAP
        - TYPE.ENCAPASS
        - TYPE.VIF
    However, our scripts work on key rather than type. So there is a need to fill in the key values for
    all the entries.
    @param param_dict: IFC configuration parameter
    @return param_dict
    '''

    for (kind, key, instance), cfg_value in param_dict.iteritems():
        value = cfg_value.get('value')
        if isinstance(value, dict):
            fill_key_strings(value)
        new_key = fill_key_strings.type2key.get(kind, '')
        if new_key:
            param_dict.pop((kind, key, instance))
            '''For Connector, fill key as 'CONN' and change instance name as external_<instance> or
            internal_<instance>
            '''
            if (kind == Type.CONN) and (key != 'CONN'):
                instance = key + '_' + instance
            param_dict[(kind, new_key, instance)] = cfg_value
    return param_dict

'Type to Key mapping for fill_key_strings function'
fill_key_strings.type2key = {
            Type.DEV:      'DeviceModel',
            Type.GRP:      'SharedConfig',
            Type.CONN:     'CONN',
#             Type.RELATION: 'IntfConfigRel',
            Type.ENCAP:    'VLAN',
            Type.ENCAPASS: 'ENCAPASS',
            Type.ENCAPREL: 'ENCAPREL',
            Type.VIF:      'VIF' }



def massage_param_dict(asa, ifc_delta_cfg_dict, transformers = None):
    '''Adjust the configuration dictionary parameter passed to us by IFC to a format suited to us.
    @param asa:  DeviceModel
    @param ifc_delta_cfg_dict: IFC configuration parameter dictionary
    @param transformers: list of function that takes one argument and return an object
        the purpose of a transformer is to transform IFC configuration dictionary to a desired format.
        The order of the application of the transformer is the reverse given in the parameter,
        i.e. if the transformers is [a, b], the result will be a(b(ifc_delta_cfg_dict)).
    @return dict
        if_cfg_dict is a equivalent of ifc_delta_cfg_dict but massaged for ifc2asa or
        generate_ifc_delta_cfg methods
    '''
    if not ifc_delta_cfg_dict:
        result = {(Type.DEV, asa.ifc_key, ''):  {'state': State.NOCHANGE, 'value': ifc_delta_cfg_dict}}
    else:
        kind, key, instance = ifc_delta_cfg_dict.keys()[0]
        if kind == Type.DEV: #for the complete configurations: device, group, function
            result = ifc_delta_cfg_dict
        else:#device configuration
            result = {(Type.DEV, asa.ifc_key, ''):  {'state': State.NOCHANGE, 'value': ifc_delta_cfg_dict}}
        'Do not modify the parameter passed to us by IFC.'
        result = copy.deepcopy(result)

    'Apply the transformations required'
    if not transformers:
        transformers = []
    transformers.append(fill_key_strings)
    for transformer in reversed(transformers):
        result = transformer(result)
    return result
